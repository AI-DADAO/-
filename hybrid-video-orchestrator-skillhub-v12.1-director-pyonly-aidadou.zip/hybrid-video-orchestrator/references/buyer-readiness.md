# 新用户安装与交付条件

本 SkillHub 版本仅包含 Director Mode 默认流程。Windows x64 用户或安装智能体先确认 Python 3.13 可用：执行 `py -3.13 -V`。若缺失且本机有 WinGet，执行 `winget install --id Python.Python.3.13 --exact --source winget --scope user --silent --accept-package-agreements --accept-source-agreements`，重新打开终端后再次检测；安装失败时停止并报告。随后在 Skill 根目录运行 `py -3.13 scripts/bootstrap.py`；安装器准备 FFmpeg、固定 Python 依赖和基础转写模型。再执行 `py -3.13 scripts/bootstrap.py --check-only` 与 `py -3.13 scripts/runner.py preflight --mode raw`。若 Python 3.13 可由 `python` 启动而无 `py` 命令，则统一改用 `python`。任何检查失败都应先处理环境问题，不使用卖家机器上的旧运行时或旧项目文件冒充成功。SkillHub 拒收 `.cmd` 启动文件，本版不含双击安装入口。

安装需要网络、WinGet 或等效系统软件来源。原始视频与文案必须来自本次任务；每条视频在新空项目中运行。AI 道具图工具、线上曲库访问、具体曲目的使用许可不在 ZIP 中，由使用者逐片核实。精剪 EDL、口气、导演计划、音乐电平、封面及最终视觉品质须审查。发布到平台前还要实际检查顶部、右侧和底部遮挡。

旧版 Three.js 人物抠像与 Remotion 信息卡属于完整包的可选三路路线，未包含在本 SkillHub 版本。若用户要求该路线，应明确提示当前包不支持，不得用 Director Mode 冒称已执行三路工程。
