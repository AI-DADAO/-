# Director Mode v11：可执行的专属构图

v11 的新项目使用 `director_plan.version: 3`。每条片至少设计两个 `layout:"designed"` 的 beat，且 `scene.id` 不同。Planner 必须从本片论点或关系推导场景，不为满足数量而换字复制。同一题材系列可以共用色彩和字体，但关键构图应让观众看出内容不同。

## 计划到画面的契约

`scene` 直接交给 `director_render.py` 绘制：

```json
{
  "id": "B05",
  "route": "VISUAL",
  "layout": "designed",
  "headline": "假期投还是不投",
  "scene": {
    "id": "holiday-70-versus-zero",
    "header": "none",
    "elements": [
      {"type":"text","text":"假期投递","x":120,"y":300,"size":42,"color":"paper"},
      {"type":"text","text":"70 > 0","x":120,"y":430,"size":104,"color":"accent","motion":"rise"},
      {"type":"bar","x":120,"y":590,"w":470,"h":30,"value":70,"max":100,"color":"mint","motion":"draw"},
      {"type":"text","text":"不投才是零机会","x":120,"y":700,"size":34,"color":"paper"}
    ]
  }
}
```

画布为 720×1280。颜色可用 `ink/paper/accent/mint` 或明确的 `#RRGGBB`。元素支持：

| type | 必要字段 | 用途 |
|---|---|---|
| `text` | `text,x,y` | 本片判断、标签或数字；可加 `size,max_width,min_size,anchor,bold,color,motion` |
| `box` | `x,y,w,h` | 信息分区和背景块；可加 `radius,color,motion` |
| `line` | `x1,y1,x2,y2` | 因果、时间或强调线；可加 `width,color,motion:"draw"` |
| `bar` | `x,y,w,h,value,max` | 数值关系；可加 `color,motion:"draw"` |
| `source_photo` | `x,y,w,h` | 本条视频当前帧的人物局部；可加 `crop:[left,top,right,bottom],border,motion` |
| `image` | `path,x,y,w,h` | 本项目提供的外部静图（如岗位表截图，path 相对项目根）；可加 `crop:[left,top,right,bottom],border,radius,motion`。素材是本项目的输入，不得复用上一项目的图；截图分辨率要足够（宽 ≥2× 显示宽），否则放大后不可读 |

`motion` 可为 `none/fade/rise/draw`。`scene.header` 可为 `none/standard`。人物段可选 `camera:{"zoom_start":1.0,"zoom_end":1.12,"pan_x":0.03,"pan_y":0}`，数值受渲染器限制以防裁脸。设计场景可用于 PERSON、PLAIN 或 VISUAL；人物段仍取自本条原片。

## 选择规则

1. 先写这个 beat 要证明的判断，再确定屏幕里的主要物体关系。比较用距离与长度；因果用方向；步骤用顺序；证据用实物或数据出处。不要把所有句子都变成大字加进度条。
2. 至少两处专属构图应来自本片独有的关系。示例中的 `70 > 0` 只适合假期投递这条片，不能作为其他视频默认画面。
3. 标题、关键数字、字幕和脸不能互相遮挡；在目标平台预览区检查。正文信息优先留在 x=120–600、y=150–1050 的可读区，装饰可在外圈。
4. 将接触表与最近成片并排看：如果封面、两个设计场景和结尾可互换，重新设计。技术 QC 只检查计划被执行和布局不重复，审美仍需人工判断。

渲染器会拒绝未知布局和未知 scene 元素；不会静默产出只有背景和字幕的 VISUAL 帧。
