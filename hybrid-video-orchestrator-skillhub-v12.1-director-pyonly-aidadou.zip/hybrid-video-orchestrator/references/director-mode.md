# Director Mode v11：计划契约与镜头语法

`intermediate/director_plan.json` 是一条新片唯一的创意时间轴。可参考同次项目的原片、目标文案与新生成的 SRT 填写；不得从旧项目复制计划或背景。

## 契约

新项目顶层包含 `version:3`、`project`、`fps:30`、`duration`、必填 `visual_identity`、`music_profile`、`cover` 和完整 `palette`（`ink`、`paper`、`accent`、`mint`），以及可选 `series_label`、`delivery_profile`、`safe_area` 和 `beats[]`。`visual_identity.family` 当前支持 `editorial`（安静的横线与留白）、`ledger`（账本行列）和 `signal`（斜线与节点）；`rationale` 与内容专属 `motif` 必填，`distinctive_compositions` 至少两项。v3 还必须有两个不同 `scene.id` 的 `designed` beat，规范见 [composition-v11.md](composition-v11.md)。美术族只改变背景几何；内容独有关系由可执行 scene 表达。每个 beat 必填：

| 字段 | 用途 |
|---|---|
| `id`, `start`, `end` | 唯一编号与本次精剪片时间窗，左闭右开，前后连续 |
| `cue` | 该窗口对应的口播提示，便于审查；不负责字幕实际内容 |
| `intent`, `takeaway`, `task` | 传播作用、观众带走的判断、唯一主要视觉任务 |
| `focus` | 此时唯一视觉焦点，如 `person`、`numbers`、`A+B` |
| `route` | 最后选 `PERSON`、`PLAIN`、`VISUAL` |
| `layout`, `headline`, `detail` | renderer 直接消费的镜头形式与字面内容 |
| `sfx` | `none`、`opening`、`tick`、`section`、`reveal`、`payoff`；由声音脚本直接消费 |

`VISUAL` beat 还要有 `visual` 数据对象；`split_list` 要有 `items`；`full_callout` 要有 `callout`。这些字段中的数值和文案是画面的唯一来源，禁止写死在组件中。

当 `delivery_profile` 是 `douyin_preview`，本次用户截图的保守安全区为 `safe_area: {"top":105,"right_edge":600,"bottom":170,"subtitle_y":1002}`，单位是 720×1280 设计画布像素。**主内容仍以画布 x=360 居中**：大数字、结论、单列图表及字幕采用 x=120–600 的对称内容带；右侧预留区不能直接把排版中心改成 x=315。顶部标签可左对齐；侧栏关键信息不得超过 `right_edge`，字幕位于 `subtitle_y` 且在底部遮挡区上方。实际抖音界面可能随设备和发布场景变化，最终以预览复核。

约每 2–4 秒一个节拍是起点；语义密集处可更短，结论需留阅读时间。脚本以每 4 秒至少一个 beat 作最低门槛，不能用一个大段掩盖多个认知转折。

## 现有布局

- `full`：本次口播画面全屏，统一色调、暗部和单行字幕。`full_rail` 增加一条信息栏；`full_callout` 读取 `callout` 绘制窄幅提示条，不得用满幅亮色矩形遮住胸口。
- `split_list`：从本次精剪片的实时帧裁出人物，与 `items` 指定的方法或结论并置。适用于需要同时保留信任感和信息结构的 beat。
- `compare`：`visual.rows` 的三项数字比较，结尾读取 `visual.conclusion` 显示判断。
- `window`：`visual.count` 指定的窗口期时间结构。
- `abc_intro`、`abc_focus`、`abc_summary`：从各 beat 的 `visual` 对象读取优先级、逐项聚焦和最终结论。`abc_focus.visual.variant` 可选 `card`、`rail`、`baseline`；连续三项应按认知角色换构图，不能只循环同一卡并换字。一个 ABC 段应有收束 beat。

`designed` 可用在三种路由，以 `scene.elements` 决定文字、人物局部、数值条、框和线的位置及简单动效。人物段还可设置 `camera` 进行有节制的推近与重构图。扩展布局时先增加表达规则和信息层级，再写组件；渲染器会拒绝未知布局，不会静默画空白背景。

## 审查顺序

1. **内容**：每个 `takeaway` 是否不同于原句复述，是否回答“观众为什么要记住”。
2. **节奏**：beat 边界是否落在语义变化处；连续同景别是否过长；结论是否有足够停留。
3. **画面**：数字有比较结论，方法有行动顺序，人物与字不互相抢焦点，字幕一行且可读。
4. **声音**：普通切无音；揭示音只为出现的重要信息服务；结论音与结论画面同步。
5. **输出**：查看全片接触表、各 beat 中点帧和切点两侧；自动报告的通过不替代人眼。

## 防模板复核

Planner 要先判断这条片的情绪、题材、人物服装与原景，再定 `visual_identity`、配色和信息图形；不得把上一项目的设置当默认值。每条片应有至少两处从该文案独有关系长出来的构图，而非换字复用同一组卡。Renderer 的三种美术族只解决背景重复，镜头节奏、人物景别、字幕排版和图表结构仍要依内容设计。将本次接触表与近期作品并排看：若去掉文案后辨认不出是哪一条，继续调整美术和构图。QC 应同时核对中心轴、平台安全区以及风格指纹；自动检查无法保证审美独特性。

## 口气与音乐验收

先运行 `tighten_pauses.py` 的建议模式，查看波形和语义，只把确实影响连贯性的静音区间写入审核 cut list。cut 边界按 30 fps 对齐；脚本拒剪大于 −30 dB RMS 的内容并同步修改视频、SRT 和现有计划。最终再次扫描标记切点，确认没有留下大于约 180 ms 的空口气。不要为了加快语速机械清除所有自然停顿。

音乐与音效分开评价。Planner 应按话题、说话速度、情绪走势、信息密度和人声可懂度写 `music_profile`，包括曲库搜索方向、节拍范围、能量曲线和淘汰理由。实际曲目逐项目在线试听并核许可；混音与证据字段见 [online-music.md](online-music.md)。`music_profile.selection` 应为 `licensed_online_library`，并在证据中写具体曲目；旧的 `procedural_original` 只说明历史项目来源，不满足当前在线曲库要求。

## AI 封面首帧

`cover` 必须包含 `style:"creator_collage"`、`art_prompt`、`eyebrow`、两条 `title_lines`、`subline` 和 `duration_frames:1`。按人物姿态选择 `portrait_side`，本片标签放在 `prop_label/footer_label`，可选 `footer_style:"paper"`。从本片 hook 和核心结论推导无字主题道具图；人物帧来自本片，中文由 `cover_intro.py` 排版。具体审美决策见 [creator-collage-cover.md](creator-collage-cover.md)。原始 AI 图、人物帧和最终封面 PNG 留在本项目。拼接后核对总帧数恰好多一帧、第一帧是封面、第二帧恢复原片、音频延后约 33 ms；发布平台仍需选中并检查缩略图。

历史外部 PERSON/PLAIN/VISUAL 管线未包含在销售候选包。当前渲染器直接依据同一导演计划实现三路画面。若后续另售 Three.js 或 Remotion 扩展，需独立声明依赖、授权与复现条件。
