# 在线免费曲库选曲与混音

本模式要求**逐项目**从官方免费曲库取得曲目。卖出的 Skill 不打包音乐文件，也不把旧项目音乐当新曲。依次查看 [Mixkit Free Stock Music](https://mixkit.co/free-stock-music/)、[Pixabay Music](https://pixabay.com/music/) 和 [Incompetech](https://incompetech.com/music/royalty-free/music.html)。若前一个站点无法下载，切换可访问的官方曲目页，不让整片停在无 BGM 状态。使用当天读取官方许可：[Mixkit 免费音乐许可](https://mixkit.co/license/modal/musicFree/)、[Pixabay 许可摘要](https://pixabay.com/service/license-summary/)、[Incompetech 音乐许可](https://incompetech.com/music/royalty-free/licenses/)。Pixabay 需额外检查 Content ID；Incompetech 的免费 CC BY 曲目需在公开视频或说明中可见署名，并注明剪辑/混音改动。许可变化以当时页面为准。

## 选择规则

Planner 先写 `music_profile`：内容情绪、节拍范围、能量曲线、是否有旁白、最密集的信息段、需要停音乐的结论段。试听至少两首完整候选，不按关键词或曲库分类盲选。

- 问题/冲突：轻推动、较少旋律抢人声；方法段保持稳定脉冲；结论段可更开阔，但不能靠骤然升响制造高潮。
- 选择无明显人声、不过密的中频旋律、不过强的鼓点；人声与歌词竞争时淘汰该曲。对齐开场、转折和结尾，不为了卡拍破坏口播节奏。
- 记录曲名、作者、**官方显示该曲名与作者的页面**、许可页、下载时间、原文件 SHA-256、选择理由、是否要求署名或存在 Content ID 风险。Mixkit 可能只在分类列表列出曲目，此时保存包含该曲的分类页及曲名；不得用曲库首页或无关页面冒充证据。CC BY 曲目还要写入可复制的署名文本与改动说明。
- 将官方页面取得的音频放在**本项目** `assets/music/`。不把它装进出售 Skill 的 ZIP；也不把只有个人下载权的录音单独转售。

`music_license_evidence.json` 最少包含 `title`、`artist`、`page_url`、`license_url`、`source`、`downloaded_at`，可以增加 `selection_reason`、`attribution`、`content_id_note`。脚本只检验字段和官方域名，**不能代替人工核实具体曲目许可**。若线上曲目无法下载或许可不明，停止“曲库配乐”交付，不自动改用程序生成音乐冒充选曲。

## 混音与验收

输入 `--video` 应是**尚未加 BGM**的导演画面成片。执行：

```text
python scripts/online_bgm.py --project <项目> --plan <最终导演计划> --video <无BGM画面.mp4> --track <本项目下载的曲目> --evidence <music_license_evidence.json> --out <带曲库BGM成片.mp4>
```

脚本测人声活跃段和曲目 RMS，先把音乐平均电平设置为至少低于人声约 18 dB；说话时再用侧链压低音乐，首尾淡入淡出，提示音按导演计划插入。18 dB 是初始混音目标，不是绝对听感标准；逐段试听确保每个字清楚，同时音乐存在感足够。检查成片开头、最密集口播、转场和结尾，并保存 `online_bgm_trace.json`。若源片已带配乐，先取得无 BGM 源，避免叠两层音乐。
