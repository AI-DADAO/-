#!/usr/bin/env python
"""
Stage 1: 从口播视频抽取音轨
- 用 ffmpeg 输出 16kHz / 单声道 / PCM wav
- 适合作为 faster-whisper 的输入

用法：
  python stage1_extract_audio.py --video video.mp4 --out intermediate/01_audio.wav
"""
from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path


def main() -> int:
    p = argparse.ArgumentParser(description="Extract 16k mono PCM wav from video via ffmpeg")
    p.add_argument("--video", required=True, help="输入视频文件 (mp4/mov/...)")
    p.add_argument("--out", required=True, help="输出 wav 路径")
    p.add_argument("--sample-rate", type=int, default=16000, help="采样率 (默认 16000)")
    p.add_argument("--channels", type=int, default=1, help="声道数 (默认 1 单声道)")
    args = p.parse_args()

    video = Path(args.video)
    out = Path(args.out)

    if not video.exists():
        print(f"[ERROR] 视频不存在: {video}", file=sys.stderr)
        return 1
    if out.exists():
        print(f"[INFO] 输出已存在, 覆盖: {out}")

    if shutil.which("ffmpeg") is None:
        print("[ERROR] 系统未找到 ffmpeg，请先安装 ffmpeg 并加入 PATH", file=sys.stderr)
        return 1

    out.parent.mkdir(parents=True, exist_ok=True)

    cmd = [
        "ffmpeg",
        "-y",                       # 覆盖输出
        "-i", str(video),
        "-vn",                      # 不要视频流
        "-ac", str(args.channels),
        "-ar", str(args.sample_rate),
        "-f", "wav",
        str(out),
    ]

    print(f"[RUN] {' '.join(cmd)}")
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        print(f"[ERROR] ffmpeg 失败 (rc={proc.returncode})", file=sys.stderr)
        print(proc.stderr[-2000:], file=sys.stderr)
        return proc.returncode

    if not out.exists() or out.stat().st_size < 1024:
        print(f"[ERROR] 输出 wav 不存在或过小: {out}", file=sys.stderr)
        return 1

    # 用 ffprobe 看一眼时长，确认是真的有内容
    probe = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", str(out)],
        capture_output=True, text=True,
    )
    duration = float(probe.stdout.strip()) if probe.stdout.strip() else 0.0
    print(f"[OK] 抽音轨成功: {out}  时长={duration:.2f}s  大小={out.stat().st_size} bytes")
    return 0


if __name__ == "__main__":
    sys.exit(main())
