#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""stage6b_srt_seg.py — 把 final.srt 重建为 ASR 段粒度 + 目标语正字（实录坑19 通用化）

问题：stage6 产出的 srt 是对齐句粒度（可能 8 条粗 cue，单条 80+ 字），
下游 chip/跟读字幕会炸行。本脚本：
  1. 从 final.mp4 抽 16k 音轨 → faster-whisper ASR → 成片轴段界（34 段左右短句）
  2. 用 difflib 字符流对齐（ASR 全文 vs 目标文案全文）把每段 ASR 文本替换为
     目标语对应片段（= 正字，免手工 FIX 表）
  3. 覆盖写 final.srt

用法（在 oral-take-editor venv 里跑，需要 faster-whisper）:
  python stage6b_srt_seg.py --final-video output/final.mp4 \
      --target target_script.md --out output/final.srt [--model base]
"""
import argparse
import difflib
import json
import re
import subprocess
import sys
from pathlib import Path


def norm(s: str) -> str:
    """匹配用规整串：只留 CJK/字母/数字。"""
    return "".join(ch for ch in s if re.match(r"[\u4e00-\u9fffA-Za-z0-9]", ch))


def norm_map(raw: str):
    """返回 (规整串, 规整idx→raw idx 映射数组)。"""
    n, idx = [], []
    for i, ch in enumerate(raw):
        if re.match(r"[\u4e00-\u9fffA-Za-z0-9]", ch):
            n.append(ch)
            idx.append(i)
    return "".join(n), idx


def ts(sec: float) -> str:
    sec = max(0.0, sec)
    ms = int(round(sec * 1000))
    return f"{ms // 3600000:02d}:{ms % 3600000 // 60000:02d}:{ms % 60000 // 1000:02d},{ms % 1000:03d}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--final-video", required=True)
    ap.add_argument("--target", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--model", default="base")
    ap.add_argument("--language", default="zh")
    args = ap.parse_args()

    video = Path(args.final_video)
    work = video.parent.parent / "intermediate"
    work.mkdir(parents=True, exist_ok=True)
    wav = work / "final_audio_16k.wav"
    if not wav.exists():
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(video),
                        "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", str(wav)],
                       check=True, timeout=120)
        print(f"[s6b] 16k 音轨 → {wav.name}")

    from faster_whisper import WhisperModel
    model = WhisperModel(args.model, device="cpu", compute_type="int8")
    segments, _ = model.transcribe(str(wav), language=args.language, vad_filter=False)
    segs = [{"start": s.start, "end": s.end, "text": s.text.strip()} for s in segments]
    if not segs:
        print("[s6b] ERROR: ASR 无输出", file=sys.stderr)
        return 2
    print(f"[s6b] ASR {len(segs)} 段")

    target_raw = Path(args.target).read_text(encoding="utf-8")
    tgt_norm, tgt_idx = norm_map(target_raw)
    asr_norm, asr_idx = norm_map("".join(s["text"] for s in segs))

    # 规整串对齐 → asr 规整位置 → 目标规整位置
    sm = difflib.SequenceMatcher(None, asr_norm, tgt_norm, autojunk=False)
    a2b: dict[int, int] = {}
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        span = max(1, i2 - i1)
        for k in range(i2 - i1):
            a2b[i1 + k] = j1 + int(k * (j2 - j1) / span)

    # 每段 ASR 文本 → 规整区间 → 目标原文片段
    out, cursor = [], 0
    for i, s in enumerate(segs):
        a0, a1 = cursor, cursor + len(norm(s["text"]))
        cursor = a1
        b0 = next((a2b[x] for x in range(a0, a1) if x in a2b), None)
        b1 = next((a2b[x] + 1 for x in range(a1 - 1, a0 - 1, -1) if x in a2b), None)
        if b0 is not None and b1 is not None and b1 > b0:
            text = target_raw[tgt_idx[b0]: tgt_idx[b1 - 1] + 1].strip()
        else:
            text = s["text"]
        out.append(f"{i + 1}\n{ts(s['start'])} --> {ts(s['end'])}\n{text}\n")

    Path(args.out).write_text("\n".join(out), encoding="utf-8")
    longs = [len(norm(s['text'])) for s in segs if len(norm(s['text'])) > 30]
    print(f"[s6b] [OK] {len(out)} 条段粒度 cue → {args.out}（>30字: {len(longs)} 条）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
