#!/usr/bin/env python
"""
Stage 3: 把 target_script.md 切成句, 在 ASR transcript 上 fuzzy 匹配, 输出 aligned.json
- target_script 支持 Markdown: 取所有文本行（去掉标题符号和列表前缀）, 按中文 。！？+ 换行切句
- 匹配算法: rapidfuzz.fuzz.partial_ratio sliding window
- 多对一: 强制错位（一对多才是正常的, 多对一意味着目标句切错了）

用法:
  python stage3_align.py --transcript 02_transcript.json --target target_script.md --out 03_aligned.json
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any


_SENT_END = re.compile(r"([。！？!?])|\n")


def split_sentences(md_text: str) -> list[str]:
    """从 Markdown 文本提取句子。
    规则:
      1. 去掉 markdown 标题符号 (#) 和列表前缀 (- *) 但保留正文
      2. 按中文 。！？! ? + 换行 切句
      3. 过滤空句 / 单字 / 纯标点
    """
    cleaned_lines = []
    for raw in md_text.splitlines():
        line = raw.strip()
        if not line:
            continue
        # 跳过 markdown 标题行 (整行丢弃, 不进正文)
        if re.match(r"^#{1,6}\s", line):
            continue
        # 去有序 / 无序列表前缀
        line = re.sub(r"^[\-\*]\s+", "", line)
        line = re.sub(r"^\d+[.、]\s*", "", line)
        cleaned_lines.append(line)

    text = "\n".join(cleaned_lines)
    # 用标点 + 换行做粗切, 保留分隔符
    parts: list[str] = []
    buf = ""
    for ch in text:
        buf += ch
        if _SENT_END.match(ch) or ch == "\n":
            s = buf.strip()
            if s and len(s) >= 4:  # 至少 4 个字符
                # 去尾部标点之后的空白
                parts.append(s.strip(" 。！？!?\n\t "))
            buf = ""
    tail = buf.strip().strip(" 。！？!?\n\t ")
    if tail and len(tail) >= 4:
        parts.append(tail)
    return parts


def normalize_text(s: str) -> str:
    """归一化用于匹配打分: 繁→简 (whisper 中文常输出繁体) + 去标点/空格.
    只影响打分, 不改原文.
    """
    try:
        from zhconv import convert
        s = convert(s, "zh-cn")
    except ImportError:
        pass
    return re.sub(r"[^\w\u4e00-\u9fff]+", "", s)


def sliding_window_match(
    target: str,
    segment_texts: list[str],
    window_pad: int = 10,
    step_ratio: float = 0.3,
    top_n: int = 3,
) -> list[dict[str, Any]]:
    """在 ASR 文本上按字符维度滑窗, 返回 top-N 个互不重叠的候选窗口 (按分数降序).
    每个候选: {"score", "lo_seg", "hi_seg"}
    窗口长度 = len(target) * 1.6 + pad (容忍 ASR 错字/插入词).
    同一句 target 有多个高分不重叠窗口 = 视频里重复录制了这句.
    """
    try:
        from rapidfuzz import fuzz
    except ImportError:
        print("[ERROR] 缺 rapidfuzz, 请 pip install rapidfuzz", file=sys.stderr)
        raise

    if not segment_texts or not target:
        return []

    # 拼 big string 并记录 每个字符 → segment_idx 的映射
    big_chars: list[str] = []
    char_seg: list[int] = []
    for i, t in enumerate(segment_texts):
        for ch in t:
            big_chars.append(ch)
            char_seg.append(i)
    big = "".join(big_chars)
    if not big:
        return []

    n = len(target)
    window = int(n * 1.6) + window_pad
    step = max(1, int(n * step_ratio))

    starts = list(range(0, max(1, len(big) - window + 1), step))
    if not starts:
        starts = [0]
    if starts[-1] + window < len(big):
        starts.append(len(big) - window)

    # 收集所有窗口 (score, char_start, char_end)
    windows: list[tuple[float, int, int]] = []
    for start in starts:
        chunk = big[start : start + window]
        s = fuzz.partial_ratio(target, chunk)
        windows.append((float(s), start, start + len(chunk)))
    windows.sort(key=lambda x: -x[0])

    # 选 top-N 互不重叠 (字符区间无交集) 的候选
    picked: list[tuple[float, int, int]] = []
    for score, cs, ce in windows:
        if any(not (ce <= ps or cs >= pe) for _, ps, pe in picked):
            continue
        picked.append((score, cs, ce))
        if len(picked) >= top_n:
            break

    # 转成 segment 范围
    out = []
    for score, cs, ce in picked:
        lo_seg = char_seg[cs]
        hi_seg = char_seg[min(ce - 1, len(big) - 1)]
        out.append({"score": score, "lo_seg": lo_seg, "hi_seg": hi_seg})
    return out


def main() -> int:
    p = argparse.ArgumentParser(description="Align target script to ASR transcript (fuzzy)")
    p.add_argument("--transcript", required=True, help="transcript.json 路径")
    p.add_argument("--target", required=True, help="target_script.md 路径")
    p.add_argument("--out", required=True, help="输出 aligned.json 路径")
    p.add_argument("--score-threshold", type=float, default=60.0,
                   help="低于此分视为 unmatched (默认 60)")
    args = p.parse_args()

    transcript = json.loads(Path(args.transcript).read_text(encoding="utf-8"))
    target_md = Path(args.target).read_text(encoding="utf-8")

    # 剥离视觉强调标记 (**加粗** / ~~删除线~~ / [[asset:...]]),
    # 保证对齐打分和字幕文本干净 (标记由 stage35 单独解析)
    from marker_utils import strip_markers
    target_md = strip_markers(target_md)

    sentences = split_sentences(target_md)
    print(f"[INFO] target 切句: {len(sentences)} 句")

    segs = transcript["segments"]
    seg_texts = [s["text"] for s in segs]
    # 归一化副本: 仅用于 fuzzy 打分 (繁→简 + 去标点)
    seg_texts_norm = [normalize_text(t) for t in seg_texts]

    aligned = []
    for idx, sent in enumerate(sentences):
        sent_norm = normalize_text(sent)
        cands = sliding_window_match(sent_norm, seg_texts_norm)
        if not cands:
            aligned.append({
                "target_idx": idx,
                "target_text": sent,
                "match_status": "unmatched",
                "score": 0.0,
                "segment_idx_range": None,
                "segment_start": None,
                "segment_end": None,
                "matched_text": None,
                "candidates": [],
            })
            continue

        best = cands[0]
        score = best["score"]
        lo, hi = best["lo_seg"], best["hi_seg"]
        status = "matched" if score >= args.score_threshold else "low_confidence"

        # 重复录制检测: 同一句有 ≥2 个过阈值的不重叠窗口
        qualified = [c for c in cands if c["score"] >= args.score_threshold]
        if len(qualified) >= 2:
            status = "duplicate_recorded"

        # 展开候选 (带时间戳和原文), 供 stage4 选优
        cands_out = []
        for c in cands:
            cl, chh = c["lo_seg"], c["hi_seg"]
            cands_out.append({
                "score": round(float(c["score"]), 2),
                "segment_idx_range": [int(cl), int(chh)],
                "segment_start": float(segs[cl]["start"]),
                "segment_end": float(segs[chh]["end"]),
                "matched_text": " ".join(seg_texts[cl : chh + 1]),
            })

        s_start = segs[lo]["start"]
        s_end = segs[hi]["end"]
        matched_text = " ".join(seg_texts[lo : hi + 1])

        aligned.append({
            "target_idx": idx,
            "target_text": sent,
            "match_status": status,
            "score": round(float(score), 2),
            "segment_idx_range": [int(lo), int(hi)],
            "segment_start": float(s_start),
            "segment_end": float(s_end),
            "matched_text": matched_text,
            "candidates": cands_out,
        })
        print(f"  [{idx:02d}] score={score:5.1f} status={status:18s} "
              f"cands={len(qualified)} {s_start:6.2f}s-{s_end:6.2f}s  {sent[:30]}")

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "target_path": str(args.target),
        "transcript_path": str(args.transcript),
        "num_target_sentences": len(sentences),
        "num_unmatched": sum(1 for a in aligned if a["match_status"] == "unmatched"),
        "num_low_confidence": sum(1 for a in aligned if a["match_status"] == "low_confidence"),
        "num_duplicate_recorded": sum(1 for a in aligned if a["match_status"] == "duplicate_recorded"),
        "alignment": aligned,
    }
    out.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[OK] 对齐完成: {out}")
    print(f"     总 {len(sentences)} 句, "
          f"unmatched={payload['num_unmatched']}, "
          f"low_confidence={payload['num_low_confidence']}, "
          f"duplicate_recorded={payload['num_duplicate_recorded']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
