#!/usr/bin/env python
"""
一键全套入口: 自动跑 Stage 1-5, 停在报告页面
- 监听 07_reviewed_edl.json 是否被用户在报告页导出 (简单做: 用户自己 cp 到目标位置)
- 然后跑 Stage 6

用法:
  python run_all.py --video video.mp4 --target target_script.md --workdir .
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


SCRIPTS = Path(__file__).parent


def run_stage(name: str, cmd: list[str], cwd: Path) -> bool:
    print(f"\n========== {name} ==========")
    print(f"[CMD] {' '.join(cmd)}")
    rc = subprocess.run(cmd, cwd=str(cwd)).returncode
    if rc != 0:
        print(f"[FAIL] {name} 退出码 {rc}", file=sys.stderr)
        return False
    return True


def main() -> int:
    p = argparse.ArgumentParser(description="Run oral-take-editor pipeline Stage 1-5")
    p.add_argument("--video", required=True)
    p.add_argument("--target", required=True)
    p.add_argument("--workdir", default=".", help="工作目录")
    p.add_argument("--model", default="base",
                   help="ASR 模型 (默认 base; large-v3 需要完整下载且本机缓存曾是空壳, 勿盲用)")
    p.add_argument("--device", default="cpu", choices=["cuda", "cpu"],
                   help="cpu 配合 --compute-type int8 是实测可靠组合; cuda 需 cublas DLL 完好")
    p.add_argument("--compute-type", default="int8", choices=["int8", "float16", "float32"])
    args = p.parse_args()

    workdir = Path(args.workdir).resolve()
    inter = workdir / "intermediate"
    inter.mkdir(parents=True, exist_ok=True)
    out = workdir / "output"
    out.mkdir(parents=True, exist_ok=True)

    py = sys.executable

    pipeline = [
        ("Stage 1: 抽音轨",
         [py, str(SCRIPTS / "stage1_extract_audio.py"),
          "--video", str(args.video), "--out", str(inter / "01_audio.wav")]),
        ("Stage 2: ASR 转写",
         [py, str(SCRIPTS / "stage2_asr.py"),
          "--audio", str(inter / "01_audio.wav"),
          "--out", str(inter / "02_transcript.json"),
          "--model", args.model, "--device", args.device,
          "--compute-type", args.compute_type, "--language", "zh"]),
        ("Stage 3: 文案对齐",
         [py, str(SCRIPTS / "stage3_align.py"),
          "--transcript", str(inter / "02_transcript.json"),
          "--target", str(args.target),
          "--out", str(inter / "03_aligned.json")]),
        ("Stage 4: EDL 生成",
         [py, str(SCRIPTS / "stage4_make_edl.py"),
          "--transcript", str(inter / "02_transcript.json"),
          "--aligned", str(inter / "03_aligned.json"),
          "--audio", str(inter / "01_audio.wav"),
          "--out", str(inter / "04_edl.json")]),
        ("Stage 5: 粗剪 + 审查报告",
         [py, str(SCRIPTS / "stage5_cut_and_report.py"),
          "--video", str(args.video),
          "--edl", str(inter / "04_edl.json"),
          "--audio", str(inter / "01_audio.wav"),
          "--out-video", str(inter / "05_processed.mp4"),
          "--out-report", str(inter / "06_report.html")]),
    ]

    for name, cmd in pipeline:
        if not run_stage(name, cmd, workdir):
            return 1

    print("\n========================================")
    print(f"[DONE] Stage 1-5 已完成")
    print(f"[NEXT] 浏览器打开: {(inter / '06_report.html')}")
    print(f"       审查后导出 reviewed EDL 到: {(inter / '07_reviewed_edl.json')}")
    print(f"       然后跑:")
    print(f"         python {SCRIPTS / 'stage6_finalize.py'} \\")
    print(f"           --video {args.video} \\")
    print(f"           --reviewed-edl {inter / '07_reviewed_edl.json'} \\")
    print(f"           --aligned {inter / '03_aligned.json'} \\")
    print(f"           --out-video {out / 'final.mp4'} \\")
    print(f"           --out-srt {out / 'final.srt'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
