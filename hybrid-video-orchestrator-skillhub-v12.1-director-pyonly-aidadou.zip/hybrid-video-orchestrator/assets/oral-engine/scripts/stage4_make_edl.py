#!/usr/bin/env python
"""
Stage 4: 根据 aligned.json 生成 EDL (edit decision list)
- 对每个 ASR segment 判断:
  * 引用次数 = 0   → DROP
  * 引用次数 = 1   → KEEP
  * 引用次数 >= 2  → DUPLICATE, 按 score = 0.6*confidence + 0.4*energy 取最优
- KEEP 段边界自动注入 breath-gap 静音缓冲 (默认 0.15s)
- 输出 EDL 格式 (json), 后续 Stage 5 / Stage 6 直接消费

用法:
  python stage4_make_edl.py --transcript 02_transcript.json --aligned 03_aligned.json --out 04_edl.json
"""
from __future__ import annotations

import argparse
import json
import math
import subprocess
import sys
from pathlib import Path
from typing import Any


def compute_segment_rms_energy(audio_path: str, start: float, end: float) -> float:
    """用 ffmpeg+astats 估算一个时间区间内的 RMS 能量 (dB).
    返回值单位 dB (越接近 0 越响, 越小越轻).
    """
    try:
        proc = subprocess.run(
            [
                "ffmpeg", "-hide_banner", "-nostats",
                "-i", audio_path,
                "-ss", f"{start:.3f}", "-to", f"{end:.3f}",
                "-af", "astats=metadata=1:reset=1:length=100",
                "-f", "null", "-",
            ],
            capture_output=True, text=True, timeout=30,
        )
    except subprocess.TimeoutExpired:
        return -60.0
    out = proc.stderr
    # 解析 "RMS level=..." 或 "RMS_level=..."
    import re
    m = re.search(r"RMS[ _]level=([-\d.]+)", out)
    if m:
        try:
            return float(m.group(1))
        except ValueError:
            return -60.0
    return -60.0


def normalize_energy_dB(db: float, floor: float = -40.0, ceil: float = 0.0) -> float:
    """dB → 0..1 线性分数, 用于综合分计算."""
    if math.isnan(db):
        return 0.0
    if db <= floor:
        return 0.0
    if db >= ceil:
        return 1.0
    return (db - floor) / (ceil - floor)


def main() -> int:
    p = argparse.ArgumentParser(description="Generate EDL from transcript + aligned")
    p.add_argument("--transcript", required=True, help="transcript.json")
    p.add_argument("--aligned", required=True, help="aligned.json")
    p.add_argument("--audio", default=None, help="01_audio.wav (用于计算段 RMS 能量)")
    p.add_argument("--out", required=True, help="输出 edl.json")
    p.add_argument("--breath-gap", type=float, default=0.15, help="口气间隔秒数 (默认 0.15)")
    p.add_argument("--silence-threshold", type=float, default=1.5,
                   help="判定'重来边界'的静音阈值秒数 (默认 1.5)")
    p.add_argument("--conf-weight", type=float, default=0.6)
    p.add_argument("--energy-weight", type=float, default=0.4)
    p.add_argument("--stall-gap", type=float, default=1.0,
                   help="保留区间内部字间死寂超过该秒数则切开 (默认 1.0, 0=关闭)")
    p.add_argument("--stall-pad", type=float, default=0.06,
                   help="切开处两侧保留的缓冲秒数 (默认 0.06)")
    args = p.parse_args()

    transcript = json.loads(Path(args.transcript).read_text(encoding="utf-8"))
    aligned = json.loads(Path(args.aligned).read_text(encoding="utf-8"))

    transcript_segments = transcript["segments"]
    segs = transcript_segments  # 兼容旧引用

    # 1. 计算每段综合分
    audio_path = args.audio or transcript.get("audio_path")
    print(f"[INFO] 计算每段综合分 (conf={args.conf_weight}, energy={args.energy_weight})")
    if audio_path:
        print(f"       音频: {audio_path}")

    segment_scores: list[dict[str, Any]] = []
    for i, seg in enumerate(segs):
        conf = seg.get("confidence") or 0.0
        db = compute_segment_rms_energy(audio_path, seg["start"], seg["end"]) if audio_path else -20.0
        energy_norm = normalize_energy_dB(db)
        score = args.conf_weight * conf + args.energy_weight * energy_norm
        segment_scores.append({
            "segment_idx": i,
            "start": seg["start"],
            "end": seg["end"],
            "text": seg["text"],
            "confidence": conf,
            "rms_db": db,
            "energy_norm": energy_norm,
            "score": score,
        })

    def window_score(lo: int, hi: int) -> float:
        """窗口 [lo, hi] 内 ASR 段的综合分均值."""
        vals = [segment_scores[j]["score"] for j in range(lo, hi + 1) if 0 <= j < len(segs)]
        return sum(vals) / len(vals) if vals else 0.0

    # 2. 每个 target 句从候选窗口里选一个保留窗口
    #    重复录制 = 同一句有 ≥2 个过阈值的不重叠候选 → 取窗口综合分最高的,
    #    其余候选窗口覆盖的段 (不被保留窗口覆盖时) 标记为 duplicate_not_best
    SCORE_THRESHOLD = 60.0
    keep_windows: list[dict[str, Any]] = []   # 保留窗口 {target_idx, lo, hi}
    dup_windows: list[dict[str, Any]] = []    # 被丢弃的重复窗口
    for a in aligned["alignment"]:
        cands = a.get("candidates") or []
        if not cands:
            continue
        qualified = [c for c in cands if c["score"] >= SCORE_THRESHOLD]
        pool = qualified if qualified else [cands[0]]  # 全不及格时用最佳候选兜底
        # 按窗口综合分 (conf×energy) 选优
        ranked = sorted(
            pool,
            key=lambda c: window_score(c["segment_idx_range"][0], c["segment_idx_range"][1]),
            reverse=True,
        )
        best = ranked[0]
        keep_windows.append({
            "target_idx": a["target_idx"],
            "lo": best["segment_idx_range"][0],
            "hi": best["segment_idx_range"][1],
            "match_score": best["score"],
        })
        for c in ranked[1:]:
            dup_windows.append({
                "target_idx": a["target_idx"],
                "lo": c["segment_idx_range"][0],
                "hi": c["segment_idx_range"][1],
                "match_score": c["score"],
            })

    keep_cover = [False] * len(segs)
    for w in keep_windows:
        for j in range(w["lo"], w["hi"] + 1):
            if 0 <= j < len(segs):
                keep_cover[j] = True
    dup_only_cover = [False] * len(segs)
    for w in dup_windows:
        for j in range(w["lo"], w["hi"] + 1):
            if 0 <= j < len(segs) and not keep_cover[j]:
                dup_only_cover[j] = True

    # 3. 决策每段
    edl: list[dict[str, Any]] = []
    for i, seg in enumerate(segs):
        s = segment_scores[i]
        owner_keeps = [w["target_idx"] for w in keep_windows if w["lo"] <= i <= w["hi"]]
        if keep_cover[i]:
            action, reason = "keep", "in_keep_window"
        elif dup_only_cover[i]:
            action, reason = "drop", "duplicate_not_best"
        else:
            action, reason = "drop", "no_reference"
        edl.append({
            "segment_idx": i,
            "start": s["start"],
            "end": s["end"],
            "text": s["text"],
            "action": action,
            "reason": reason,
            "score": s["score"],
            "confidence": s["confidence"],
            "matches": owner_keeps,
        })

    # 4. 处理静音边界 & 注入 breath-gap
    #    检测方式: 段之间间隔 > silence_threshold 且前段是 keep / 后段是 keep
    for k in range(len(edl) - 1):
        gap = edl[k + 1]["start"] - edl[k]["end"]
        if gap >= args.silence_threshold:
            edl[k]["is_boundary"] = True
            edl[k + 1]["is_boundary"] = True

    # 5. 生成最终 strip: 合并重叠/近邻 keep 段 → keep 区间 + 段间 breath-gap
    keep_entries = [e for e in edl if e["action"] == "keep"]
    keep_entries.sort(key=lambda e: e["start"])
    # 合并: 相邻区间 gap < 0.3s (连续语流被 ASR 切开) 或重叠 → 合并为一个区间
    MERGE_GAP = 0.3
    merged: list[dict[str, Any]] = []
    for e in keep_entries:
        if merged and e["start"] - merged[-1]["end"] < MERGE_GAP:
            merged[-1]["end"] = max(merged[-1]["end"], e["end"])
            merged[-1]["segment_idxs"].append(e["segment_idx"])
            merged[-1]["texts"].append(e["text"])
        else:
            merged.append({
                "start": e["start"],
                "end": e["end"],
                "segment_idxs": [e["segment_idx"]],
                "texts": [e["text"]],
            })

    # 5b. 拆掉保留区间内部的字间死寂 (卡壳停顿/等提词器): 用字级时间戳找 >stall-gap 的空洞,
    #     在空洞处切开 (两边各留 stall-pad), 切开处走 strip gap 注入 breath-gap。
    #     实测案例: 说完"家"字停了 12.4s 再接"里有27届孩子的", 整段保留会让成片字幕挂着但人 12 秒不说话。
    def split_stalls(a: float, b: float) -> list[tuple[float, float]]:
        """用字级时间戳把 [a,b] 内部 > stall_gap 的死寂空洞切开."""
        ws = sorted((float(w["start"]), float(w["end"]))
                    for s in transcript_segments if s["end"] > a and s["start"] < b
                    for w in (s.get("words") or [])
                    if float(w["end"]) > a and float(w["start"]) < b)
        if not ws:
            return [(a, b)]
        parts: list[tuple[float, float]] = []
        cur_start = a
        prev_end = a
        for x, y in ws:
            if x - prev_end > args.stall_gap and x > a + 0.3 and y < b - 0.3:
                parts.append((cur_start, min(b, prev_end + args.stall_pad)))
                cur_start = max(a, x - args.stall_pad)
            prev_end = max(prev_end, y)
        parts.append((cur_start, b))
        return parts

    subdivided: list[dict[str, Any]] = []
    for m in merged:
        pieces = split_stalls(m["start"], m["end"])
        for j, (pa, pb) in enumerate(pieces):
            subdivided.append({
                "start": pa, "end": pb,
                "segment_idxs": m["segment_idxs"] if j == 0 else [],
                "texts": m["texts"] if j == 0 else [],
                "stall_split": j > 0,
            })

    final_strip: list[dict[str, Any]] = []
    for k, m in enumerate(subdivided):
        final_strip.append({
            "type": "keep",
            "start": m["start"],
            "end": m["end"],
            "segment_idxs": m["segment_idxs"],
            "text": " ".join(m["texts"]),
        })
        if k < len(subdivided) - 1:
            final_strip.append({"type": "gap", "duration": args.breath_gap})
    keep_count = len(subdivided)

    payload = {
        "video_path": None,
        "transcript_path": str(args.transcript),
        "aligned_path": str(args.aligned),
        "breath_gap_seconds": args.breath_gap,
        "silence_threshold_seconds": args.silence_threshold,
        "weights": {"confidence": args.conf_weight, "energy": args.energy_weight},
        "edl": edl,
        "strip": final_strip,
        "stats": {
            "total_segments": len(edl),
            "kept": sum(1 for e in edl if e["action"] == "keep"),
            "dropped": sum(1 for e in edl if e["action"] == "drop"),
            "boundaries": sum(1 for e in edl if e.get("is_boundary")),
            "duplicates_resolved": sum(1 for e in edl if e["reason"] == "duplicate_not_best"),
        },
    }
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[OK] EDL 已生成: {out}")
    print(f"     总段数: {payload['stats']['total_segments']}, "
          f"KEEP: {payload['stats']['kept']}, "
          f"DROP: {payload['stats']['dropped']}, "
          f"boundaries: {payload['stats']['boundaries']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
