#!/usr/bin/env python
"""
Stage 6: 根据用户审查后的 reviewed EDL 精剪 + 生成软字幕 SRT
- 输入 reviewed_edl.json (来自 06_report.html 的 [导出] 按钮, 用户可手动调整)
- 输入 03_aligned.json (用于把 KEEP 段映射回 target 句, 推导 SRT 时间戳)
- 输出 final.mp4 + final.srt

SRT 设计:
  - 每句 target = 1 个 cue
  - 时间戳 = 该 target 在 KEEP 段里的最早 start / 最晚 end (用户审查后, 段可能合并/拆)
  - 多遍时, 用户改的是 EDL, 我们用 reviewed EDL 里每段的 start/end 反向映射到 target_idx

用法:
  python stage6_finalize.py --video video.mp4 --reviewed-edl 07_reviewed_edl.json \
    --aligned 03_aligned.json --out-video final.mp4 --out-srt final.srt
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any


def parse_srt_time(t: float) -> str:
    """秒数 → SRT hh:mm:ss,mmm"""
    if t < 0:
        t = 0
    h = int(t // 3600)
    m = int((t % 3600) // 60)
    s = int(t % 60)
    ms = int(round((t - int(t)) * 1000))
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def ffmpeg_segment_cut_with_subs(
    video: str, keep_ranges: list[tuple[float, float]],
    srt_path: str, out_path: str, breath_gap: float = 0.15,
    burn_subtitles: bool = False,
) -> int:
    """按 reviewed EDL 剪辑视频. burn_subtitles=False 时不烧字幕, 只裁视频+注入 breath.
    字幕由用户外挂在播放器或 ffmpeg 后续烧录.
    """
    if shutil.which("ffmpeg") is None:
        print("[ERROR] 系统未找到 ffmpeg", file=sys.stderr)
        return 1

    # 统一采样率/声道, 避免 concat 报 "non matching input" (视频音轨常见 48k stereo)
    SR = 48000
    parts: list[str] = []
    for i, (s, e) in enumerate(keep_ranges):
        # 视频段尾部克隆最后一帧补 breath_gap: 音频在段间插了静音气口,
        # 视频若不补齐就会比音频短 (段数×gap), 片尾定格/播放器提前结束 (2026-09-24 实测踩坑)
        pad = f",tpad=stop_mode=clone:stop_duration={breath_gap:.3f}" if i < len(keep_ranges) - 1 else ""
        parts.append(
            f"[0:v]trim=start={s:.3f}:end={e:.3f},setpts=PTS-STARTPTS{pad}[v{i}v];"
            f"[0:a]atrim=start={s:.3f}:end={e:.3f},asetpts=PTS-STARTPTS,"
            f"aformat=sample_rates={SR}:channel_layouts=stereo[a{i}a]"
        )
    # 段间静音: anullsrc 是 source filter, 直接生成 → atrim 到 breath_gap
    audio_inputs = []
    for i, _ in enumerate(keep_ranges):
        audio_inputs.append(f"[a{i}a]")
        if i < len(keep_ranges) - 1:
            parts.append(
                f"anullsrc=r={SR}:cl=stereo,atrim=0:{breath_gap:.3f},"
                f"asetpts=PTS-STARTPTS[s{i}s]"
            )
            audio_inputs.append(f"[s{i}s]")
    concat_v = "".join(f"[v{i}v]" for i in range(len(keep_ranges)))
    parts.append(f"{concat_v}concat=n={len(keep_ranges)}:v=1:a=0[vout]")
    concat_a = "".join(audio_inputs)
    parts.append(f"{concat_a}concat=n={len(audio_inputs)}:v=0:a=1[aout]")

    filter_complex = ";".join(parts)
    cmd = [
        "ffmpeg", "-y", "-i", video,
        "-filter_complex", filter_complex,
        "-map", "[vout]", "-map", "[aout]",
        "-c:v", "libx264", "-preset", "ultrafast", "-crf", "20",
        "-c:a", "aac", "-b:a", "128k",
    ]
    if burn_subtitles:
        # 烧字幕: 简化做法 - 让 ffmpeg 直接染上 SRT. font 需要 msyh.ttc (Windows 系统字体)
        font_path = "C:/Windows/Fonts/msyh.ttc"
        if Path(font_path).exists():
            vf = (
                f"[vout]subtitles={srt_path}:force_style='FontName=Microsoft YaHei,"
                f"FontSize=22,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,"
                f"BorderStyle=1,Outline=1,Shadow=0,Alignment=2'[vsub]"
            )
            # 上面的 subtitles 在 filter_complex 里需要重新链
            cmd = [
                "ffmpeg", "-y", "-i", video,
                "-filter_complex", filter_complex,
                "-map", "[vout]", "-map", "[aout]",
                "-vf", f"subtitles={srt_path}:force_style='FontName=Microsoft YaHei,FontSize=22'",
                "-c:v", "libx264", "-preset", "ultrafast", "-crf", "20",
                "-c:a", "aac", "-b:a", "128k",
            ]
        else:
            print(f"[WARN] 未找到字体 {font_path}, 跳过硬字幕烧录")

    cmd.append(out_path)

    print(f"[RUN] ffmpeg 剪辑 ({len(keep_ranges)} 段 keep)...burn_subs={burn_subtitles}")
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        print(f"[ERROR] ffmpeg 失败 (rc={proc.returncode})", file=sys.stderr)
        print(proc.stderr[-2000:], file=sys.stderr)
        return proc.returncode
    return 0


def build_srt_from_reviewed(
    reviewed_edl: dict, aligned: dict
) -> list[dict[str, Any]]:
    """根据 reviewed EDL + aligned 生成 cue (基于原始视频时间轴).

    关键约束: 一个 ASR 段只能归属一个 target 句, 保证 cue 之间不重叠
    (否则会出现多句字幕同时显示, 违背"一句一句出现"的需求).

    归属规则: 段被多个 target 窗口覆盖时, 分给「对齐分数最高」的 target.
    cue 时间 = 该 target 分到的段的 min(start) ~ max(end).
    """
    target_best_score = {a["target_idx"]: a.get("score", 0) for a in aligned["alignment"]}
    # 每句 target 最佳窗口的时间中心 (用于段归属)
    target_center: dict[int, float] = {}
    for a in aligned["alignment"]:
        if a.get("segment_start") is not None and a.get("segment_end") is not None:
            target_center[a["target_idx"]] = (a["segment_start"] + a["segment_end"]) / 2.0

    seg_owner: dict[int, int] = {}
    for e in reviewed_edl["edl"]:
        if e["action"] != "keep":
            continue
        matches = e.get("matches") or []
        if not matches:
            continue
        seg_center = (e["start"] + e["end"]) / 2.0
        # 归属 = 盖住它的 target 窗口中, 窗口中心离段中心最近的那个
        best_t = min(
            matches,
            key=lambda t: abs(target_center.get(t, 1e9) - seg_center),
        )
        seg_owner[e["segment_idx"]] = best_t

    target_segments: dict[int, list[dict[str, Any]]] = {}
    for e in reviewed_edl["edl"]:
        if e["action"] != "keep":
            continue
        t = seg_owner.get(e["segment_idx"])
        if t is None:
            continue
        target_segments.setdefault(t, []).append(e)

    alignment = aligned["alignment"]
    cues: list[dict[str, Any]] = []
    for tidx in sorted(target_segments):
        segs = sorted(target_segments[tidx], key=lambda x: x["start"])
        start = segs[0]["start"]
        end = segs[-1]["end"]
        if tidx >= len(alignment):
            continue
        text = alignment[tidx]["target_text"]
        cues.append({"start": start, "end": end, "text": text})
    return cues


def map_cues_to_final_time(
    cues: list[dict[str, Any]], keep_ranges: list[tuple[float, float]], breath_gap: float
) -> list[dict[str, Any]]:
    """把基于原始视频的时间戳映射到 final.mp4 (拼接后) 的时间.
    keep_ranges 是 reviewed EDL 的 KEEP 区间 (原始时间), final 时间 = 区间顺序拼接,
    区间之间插入 breath_gap. cue 可能跨区间 (跨越被剪掉的 gap), start/end 分别映射.
    """
    # 分段线性映射表: (orig_start, orig_end, final_start)
    seg_map: list[tuple[float, float, float]] = []
    cursor = 0.0
    for k, (s, e) in enumerate(keep_ranges):
        seg_map.append((s, e, cursor))
        cursor += (e - s) + (breath_gap if k < len(keep_ranges) - 1 else 0.0)

    def map_t(t: float) -> float:
        for s, e, fs in seg_map:
            if s <= t <= e:
                return fs + (t - s)
        # 落在被剪掉的区域: 映射到「前一个区间末尾 + gap/2」或「后一个区间开头」
        prev_end = None
        for s, e, fs in seg_map:
            if t > e:
                prev_end = fs + (e - s)
            elif t < s:
                return fs
        if prev_end is not None:
            return prev_end + breath_gap / 2.0
        return 0.0

    out = []
    for c in cues:
        ns = map_t(c["start"])
        ne = map_t(c["end"])
        if ne <= ns:
            ne = ns + 0.1
        out.append({"start": ns, "end": ne, "text": c["text"]})

    # 排序 + 消除相邻 cue 重叠 (一句一句出现, 不叠屏)
    out.sort(key=lambda x: x["start"])
    for i in range(len(out) - 1):
        if out[i]["end"] > out[i + 1]["start"]:
            out[i]["end"] = out[i + 1]["start"]
        if out[i]["end"] <= out[i]["start"]:
            out[i]["end"] = out[i]["start"] + 0.1
    for i, c in enumerate(out, 1):
        c["idx"] = i
    return out


def write_srt(cues: list[dict[str, Any]], out_path: Path) -> None:
    lines = []
    for c in cues:
        lines.append(str(c["idx"]))
        lines.append(f"{parse_srt_time(c['start'])} --> {parse_srt_time(c['end'])}")
        lines.append(c["text"])
        lines.append("")  # 空行
    out_path.write_text("\n".join(lines), encoding="utf-8")


def main() -> int:
    p = argparse.ArgumentParser(description="Finalize: cut final.mp4 + emit final.srt")
    p.add_argument("--video", required=True, help="原始视频")
    p.add_argument("--reviewed-edl", required=True, help="07_reviewed_edl.json")
    p.add_argument("--aligned", required=True, help="03_aligned.json")
    p.add_argument("--out-video", required=True, help="final.mp4 输出")
    p.add_argument("--out-srt", required=True, help="final.srt 输出")
    p.add_argument("--breath-gap", type=float, default=0.15)
    p.add_argument("--burn-subtitles", action="store_true",
                   help="烧字幕到 final.mp4 (需要 Windows 字体 msyh.ttc)")
    args = p.parse_args()

    if not Path(args.video).exists():
        print(f"[ERROR] 视频不存在: {args.video}", file=sys.stderr)
        return 1
    reviewed = json.loads(Path(args.reviewed_edl).read_text(encoding="utf-8"))
    aligned = json.loads(Path(args.aligned).read_text(encoding="utf-8"))

    if reviewed.get("strip"):
        # strip 是报告导出时合并后的 keep 区间
        keep_ranges = [
            (s["start"], s["end"])
            for s in reviewed["strip"] if s["type"] == "keep"
        ]
    else:
        keep_ranges = [
            (e["start"], e["end"])
            for e in reviewed["edl"] if e["action"] == "keep"
        ]
    print(f"[INFO] reviewed EDL 共 {len(keep_ranges)} 段 KEEP")

    # 1. 写 SRT (基于原视频时间戳)
    cues_original = build_srt_from_reviewed(reviewed, aligned)
    # 2. 映射到 final.mp4 时间戳
    cues_final = map_cues_to_final_time(
        cues_original, keep_ranges, args.breath_gap
    )
    out_srt = Path(args.out_srt)
    out_srt.parent.mkdir(parents=True, exist_ok=True)
    write_srt(cues_final, out_srt)
    print(f"[OK] SRT 已生成: {out_srt}  共 {len(cues_final)} 句字幕")

    # 3. 精剪视频
    out_v = Path(args.out_video)
    out_v.parent.mkdir(parents=True, exist_ok=True)
    rc = ffmpeg_segment_cut_with_subs(
        args.video, keep_ranges, str(out_srt), str(out_v),
        breath_gap=args.breath_gap,
        burn_subtitles=args.burn_subtitles,
    )
    if rc != 0:
        return rc
    print(f"[OK] 精剪视频: {out_v}")
    print(f"     时长 ≈ {sum(e - s for s, e in keep_ranges) + args.breath_gap * (len(keep_ranges) - 1):.2f}s")
    if args.burn_subtitles:
        print(f"     [已烧字幕到视频]")
    else:
        print(f"     [软字幕外挂] 用播放器打开 final.mp4 + 同时挂载 final.srt 即可; 或 ffmpeg -i final.mp4 -i final.srt -c copy -c:s mov_text out_burned.mp4")
    return 0


if __name__ == "__main__":
    sys.exit(main())
