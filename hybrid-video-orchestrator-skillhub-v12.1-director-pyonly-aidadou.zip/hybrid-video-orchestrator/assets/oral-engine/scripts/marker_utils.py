#!/usr/bin/env python
"""标记解析共享模块: target_script.md 的视觉强调标记语法.

语法:
  **关键词**            强制指定关键词 (字幕变色 + 弹出胶囊)
  ~~词~~                从 AI 提炼结果里排除
  [[asset:a.png,b.png]] 该行插入产品素材 (横屏→顶部卡片, 竖屏→矩阵网格)

stage3 对齐前用 strip_markers() 拿干净文本;
stage35 用 parse_line_markers() 拿结构化标记.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

MARK_BOLD = re.compile(r"\*\*(.+?)\*\*")
MARK_STRIKE = re.compile(r"~~(.+?)~~")
MARK_ASSET = re.compile(r"\[\[asset:([^\]]+?)\]\]")

# AI 提炼时要跳过的虚词/停用词 (出现在关键词候选里即降权)
STOPWORDS = set("的了是在有我你他她它这那不也就都很还并或者与及等把被让对从向着到之为")

# 卖点/口感/特色词表 (extract_auto_keywords 规则 2): 命中即视为卖点候选.
# 参考 2026-09-24 剪映餐饮口播教学 — 关键词判断 = 挑「菜品名/特色/口感」做重点;
# 菜品名等专有名词正则无法识别, 用 **加粗** 强制标记.
SELLING_CHARS = "鲜嫩香辣脆甜爽滑糯麻酸浓醇清爽汁多现熬现煮现做手工秘制招牌必点隐藏限定独家祖传正宗爆汁软绵酥"


def strip_markers(text: str) -> str:
    """剥离所有标记语法, 返回干净文本 (标记内文保留, asset 引用整体删除)."""
    text = MARK_ASSET.sub(" ", text)
    text = MARK_BOLD.sub(r"\1", text)
    text = MARK_STRIKE.sub(r"\1", text)
    return text


@dataclass
class LineMarkers:
    """一行的标记解析结果."""
    bold: list[str] = field(default_factory=list)      # 强制关键词
    strike: list[str] = field(default_factory=list)    # 排除词
    assets: list[list[str]] = field(default_factory=list)  # 每组 = 一行里的一个 [[asset:...]] (多文件)
    clean_text: str = ""                               # 剥离后的该行文本


def parse_line_markers(line: str) -> LineMarkers:
    lm = LineMarkers()
    lm.assets = [
        [f.strip() for f in group.split(",") if f.strip()]
        for group in MARK_ASSET.findall(line)
    ]
    lm.bold = [m for m in MARK_BOLD.findall(line)]
    lm.strike = [m for m in MARK_STRIKE.findall(line)]
    lm.clean_text = strip_markers(line)
    return lm


def extract_auto_keywords(sentence: str, max_per_sentence: int = 2) -> list[str]:
    """AI 规则提炼一句里的关键词候选 (加粗/删除线之外的补充).

    规则 (V2, 纯启发式, 不依赖分词库; V2 加入卖点词表 — 参考 2026-09-24 剪映餐饮口播教学:
    关键词判断 = 语义类别挑选, 「菜品名/特色/口感」这类卖点词挑出来做重点):
      1. 含数字的短语 (阿拉伯数字 + 前后各 0-6 个汉字) — 「买一年送一年」「39 家」
      2. 卖点/口感/特色词 (SELLING_CHARS 词表命中, 2-6 字) — 「清甜汤底」「秘制」「现熬」;
         菜品名等专有名词正则没法识别, 用 **加粗** 强制标记
      3. 「不/没 + 动词/形容词」否定结构 2-6 字 — 「不限专业」「不用四处刷官网」
      4. 大写英文缩写 / 品牌词 (AI, HR, P7)
    返回去重列表, 每句最多 max_per_sentence 个.
    """
    candidates: list[str] = []

    # 1. 数字短语
    for m in re.finditer(r"[\u4e00-\u9fff]{0,6}\d+[\u4e00-\u9fff]{0,6}", sentence):
        w = m.group(0)
        if len(w) >= 2:
            candidates.append(w)

    # 2. 卖点/口感/特色词 (含词表字即候选, 截掉虚词头尾)
    for m in re.finditer(r"[\u4e00-\u9fff]{0,3}[" + SELLING_CHARS + r"][\u4e00-\u9fff]{0,3}", sentence):
        w = m.group(0)
        w = re.sub(r"^[的了是在有这那就很与及等又再]+", "", w)
        w = re.sub(r"[的了是在有这那就很与及等]+$", "", w)
        if 2 <= len(w) <= 6:
            candidates.append(w)

    # 2. 否定结构
    for m in re.finditer(r"[不没][\u4e00-\u9fff]{1,6}", sentence):
        w = m.group(0)
        # 截掉常见虚词尾巴
        w = re.sub(r"[的了是在有这那就很与及等]+$", "", w)
        if 2 <= len(w) <= 6:
            candidates.append(w)

    # 3. 英文词
    for m in re.finditer(r"[A-Za-z][A-Za-z0-9]{1,9}", sentence):
        candidates.append(m.group(0))

    # 去重 + 排除纯虚词
    seen: set[str] = set()
    out: list[str] = []
    for w in candidates:
        if w in seen:
            continue
        seen.add(w)
        # 全部字符都是停用词则跳过
        if all(ch in STOPWORDS for ch in w):
            continue
        out.append(w)
        if len(out) >= max_per_sentence:
            break
    return out
