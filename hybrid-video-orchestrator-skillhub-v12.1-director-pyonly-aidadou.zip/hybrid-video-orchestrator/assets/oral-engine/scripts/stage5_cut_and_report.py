#!/usr/bin/env python
"""
Stage 5: 按 EDL 用 ffmpeg 粗剪视频, 并生成可视化审查报告 (单文件 HTML)
- 拼接方式: 用 segment + atempo, concat demuxer
- 报告: 内嵌 wav 播放器, 时间轴可视化, 每段标绿/红/黄
- 导出 reviewed EDL: 报告页里点 [Export Reviewed EDL] 会下载 07_reviewed_edl.json (Base64 内嵌在 HTML 里)

用法:
  python stage5_cut_and_report.py --video video.mp4 --edl 04_edl.json --out-video 05_processed.mp4 --out-report 06_report.html
"""
from __future__ import annotations

import argparse
import base64
import json
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any


def ffmpeg_segment_cut(video: str, keep_ranges: list[tuple[float, float]],
                       out_path: str, breath_gap: float = 0.15) -> int:
    """用 segment + atrim + adelay + concat 做剪辑.
    - 段间注入 0.15s 静音缓冲
    """
    if not keep_ranges:
        print("[ERROR] 没有 KEEP 段, 无法剪辑", file=sys.stderr)
        return 1

    if shutil.which("ffmpeg") is None:
        print("[ERROR] 系统未找到 ffmpeg", file=sys.stderr)
        return 1

    # 统一采样率/声道, 避免 concat 报 "non matching input" (视频音轨常见 48k stereo)
    SR = 48000
    parts: list[str] = []
    for i, (s, e) in enumerate(keep_ranges):
        # 视频段尾部克隆最后一帧补 breath_gap, 与音频气口对齐 (否则视频流比音频流短, 片尾定格)
        pad = f",tpad=stop_mode=clone:stop_duration={breath_gap:.3f}" if i < len(keep_ranges) - 1 else ""
        parts.append(
            f"[0:v]trim=start={s:.3f}:end={e:.3f},setpts=PTS-STARTPTS{pad}[v{i}v];"
            f"[0:a]atrim=start={s:.3f}:end={e:.3f},asetpts=PTS-STARTPTS,"
            f"aformat=sample_rates={SR}:channel_layouts=stereo[a{i}a]"
        )
    concat_v = "".join(f"[v{i}v]" for i in range(len(keep_ranges)))
    # 段间静音: anullsrc 是 source filter, 直接生成 → atrim 到 breath_gap
    audio_inputs = []
    for i in range(len(keep_ranges)):
        audio_inputs.append(f"[a{i}a]")
        if i < len(keep_ranges) - 1:
            parts.append(
                f"anullsrc=r={SR}:cl=stereo,atrim=0:{breath_gap:.3f},"
                f"asetpts=PTS-STARTPTS[s{i}s]"
            )
            audio_inputs.append(f"[s{i}s]")
    concat_a = "".join(audio_inputs)
    parts.append(f"{concat_v}concat=n={len(keep_ranges)}:v=1:a=0[vout]")
    parts.append(f"{concat_a}concat=n={len(audio_inputs)}:v=0:a=1[aout]")

    filter_complex = ";".join(parts)

    cmd = [
        "ffmpeg", "-y",
        "-i", video,
        "-filter_complex", filter_complex,
        "-map", "[vout]", "-map", "[aout]",
        "-c:v", "libx264", "-preset", "ultrafast", "-crf", "18",
        "-c:a", "aac", "-b:a", "128k",
        out_path,
    ]
    print(f"[RUN] {' '.join(cmd[:8])} ... ({len(cmd)} args total)")
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        print(f"[ERROR] ffmpeg 剪辑失败 (rc={proc.returncode})", file=sys.stderr)
        print(proc.stderr[-2000:], file=sys.stderr)
        return proc.returncode
    return 0


def render_report_html(edl: dict, audio_path: str, out_html: Path, video_path: str) -> None:
    """生成单文件 HTML 审查报告."""
    segments = edl["edl"]
    audio_b64 = ""
    if Path(audio_path).exists():
        audio_bytes = Path(audio_path).read_bytes()
        audio_b64 = base64.b64encode(audio_bytes).decode("ascii")

    rows = []
    for seg in segments:
        action = seg["action"]
        if action == "keep":
            cls = "keep"
            icon = "✓"
        elif action == "drop" and seg["reason"] == "duplicate_not_best":
            cls = "dup"
            icon = "≈"
        else:
            cls = "drop"
            icon = "✗"
        rows.append({
            "idx": seg["segment_idx"],
            "start": seg["start"],
            "end": seg["end"],
            "text": seg["text"],
            "cls": cls,
            "icon": icon,
            "score": seg["score"],
            "confidence": seg["confidence"],
            "reason": seg["reason"],
            "ref_count": len(seg.get("matches", [])),
            "matches": seg.get("matches", []),
        })

    # 时间轴的归一化: 总时长
    total_dur = max(s["end"] for s in segments) if segments else 0
    strips = []
    for r in rows:
        left = (r["start"] / total_dur * 100) if total_dur > 0 else 0
        width = ((r["end"] - r["start"]) / total_dur * 100) if total_dur > 0 else 0
        strips.append({
            **r, "left_pct": left, "width_pct": max(0.5, width),
        })

    # 数据嵌入
    data_json = json.dumps(
        {
            "rows": strips,
            "video_path": str(video_path),
            "edl": edl,
            "breath_gap": edl.get("breath_gap_seconds", 0.15),
        },
        ensure_ascii=False, indent=None,
    )

    template = (Path(__file__).parent.parent / "templates" / "report_template.txt").read_text(encoding="utf-8")
    html = (template
            .replace("{{ROWS_JSON}}", data_json)
            .replace("{{AUDIO_BASE64}}", audio_b64)
            .replace("{{TOTAL_DURATION}}", f"{total_dur:.2f}"))
    out_html.write_text(html, encoding="utf-8")


def main() -> int:
    p = argparse.ArgumentParser(description="Cut video per EDL and emit review report")
    p.add_argument("--video", required=True, help="原始视频路径")
    p.add_argument("--edl", required=True, help="04_edl.json")
    p.add_argument("--out-video", required=True, help="粗剪输出 mp4 路径")
    p.add_argument("--out-report", required=True, help="审查报告 HTML 路径")
    p.add_argument("--audio", default=None, help="音轨 wav 路径 (报告要嵌入播放)")
    args = p.parse_args()

    video = Path(args.video)
    if not video.exists():
        print(f"[ERROR] 视频不存在: {video}", file=sys.stderr)
        return 1

    edl_data = json.loads(Path(args.edl).read_text(encoding="utf-8"))
    if edl_data.get("strip"):
        # strip 是 stage4 合并重叠后的 keep 区间 + gap
        keep_ranges = [
            (s["start"], s["end"])
            for s in edl_data["strip"] if s["type"] == "keep"
        ]
    else:
        keep_ranges = [
            (seg["start"], seg["end"])
            for seg in edl_data["edl"] if seg["action"] == "keep"
        ]
    print(f"[INFO] 共 {len(keep_ranges)} 段 KEEP, 总原始时长累加: {sum(e - s for s, e in keep_ranges):.2f}s")
    if not keep_ranges:
        print("[ERROR] EDL 里没有 KEEP 段, 请检查 Stage 4", file=sys.stderr)
        return 1

    out_v = Path(args.out_video)
    out_v.parent.mkdir(parents=True, exist_ok=True)
    rc = ffmpeg_segment_cut(str(video), keep_ranges, str(out_v),
                            breath_gap=edl_data.get("breath_gap_seconds", 0.15))
    if rc != 0:
        return rc
    print(f"[OK] 粗剪视频: {out_v}")

    audio = args.audio
    if audio is None:
        # 尝试从 edl_data 找 (不严谨, 退而求其次)
        audio = str(Path(args.edl).parent / "01_audio.wav")
    out_r = Path(args.out_report)
    out_r.parent.mkdir(parents=True, exist_ok=True)
    render_report_html(edl_data, audio, out_r, str(video))
    print(f"[OK] 审查报告: {out_r}")
    print(f"[NEXT] 浏览器打开 {out_r}, 审查后导出 reviewed EDL 到 intermediate/07_reviewed_edl.json, 然后跑 Stage 6.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
