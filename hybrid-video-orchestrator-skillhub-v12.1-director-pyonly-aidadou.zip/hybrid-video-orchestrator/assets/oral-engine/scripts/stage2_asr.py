#!/usr/bin/env python
"""
Stage 2: 用 faster-whisper 对音频做 ASR 转写, 输出带字级时间戳的 transcript.json
- 默认 large-v3 + 本地 GPU
- 中文场景推荐: large-v3 / medium, word_timestamps=True
- 输出 schema: 见 main() 末尾注释

用法:
  python stage2_asr.py --audio 01_audio.wav --out 02_transcript.json --model large-v3 --device cuda
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any


def main() -> int:
    p = argparse.ArgumentParser(description="ASR via faster-whisper")
    p.add_argument("--audio", required=True, help="输入 wav 路径")
    p.add_argument("--out", required=True, help="输出 transcript.json 路径")
    p.add_argument("--model", default="large-v3", help="whisper 模型 (默认 large-v3)")
    p.add_argument("--device", default="cuda", choices=["cuda", "cpu"], help="推理设备")
    p.add_argument("--compute-type",
                   default=None,
                   help="ctranslate2 compute_type (e.g. float16, int8_float16, int8); 默认按 device 自动")
    p.add_argument("--language", default="zh", help="语言代码 (zh/en/auto)")
    p.add_argument("--beam-size", type=int, default=5)
    p.add_argument("--vad-filter", action="store_true", default=True, help="启用 VAD 过滤静音段")
    args = p.parse_args()

    audio = Path(args.audio)
    out = Path(args.out)
    if not audio.exists():
        print(f"[ERROR] 音频不存在: {audio}", file=sys.stderr)
        return 1

    try:
        from faster_whisper import WhisperModel
    except ImportError:
        print("[ERROR] 缺 faster-whisper，请: pip install faster-whisper", file=sys.stderr)
        return 1

    if args.compute_type is None:
        compute_type = "float16" if args.device == "cuda" else "int8"
    else:
        compute_type = args.compute_type

    print(f"[INFO] 加载模型 {args.model} (device={args.device}, compute_type={compute_type})...")
    model = WhisperModel(args.model, device=args.device, compute_type=compute_type)

    print(f"[INFO] 转写: {audio} ...")
    segments_iter, info = model.transcribe(
        str(audio),
        language=args.language,
        beam_size=args.beam_size,
        word_timestamps=True,
        vad_filter=args.vad_filter,
    )

    segments: list[dict[str, Any]] = []
    for seg in segments_iter:
        words: list[dict[str, Any]] = []
        if seg.words:
            for w in seg.words:
                words.append({
                    "word": w.word,
                    "start": float(w.start) if w.start is not None else None,
                    "end": float(w.end) if w.end is not None else None,
                    "prob": float(w.probability) if w.probability is not None else None,
                })
        # 段级 confidence = 字级 prob 的均值
        probs = [w["prob"] for w in words if w["prob"] is not None]
        avg_prob = sum(probs) / len(probs) if probs else None

        segments.append({
            "id": seg.id,
            "start": float(seg.start),
            "end": float(seg.end),
            "text": seg.text.strip(),
            "avg_logprob": float(seg.avg_logprob) if seg.avg_logprob is not None else None,
            "no_speech_prob": float(seg.no_speech_prob) if seg.no_speech_prob is not None else None,
            "confidence": avg_prob,
            "words": words,
        })

    out.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "audio_path": str(audio),
        "language": info.language,
        "language_probability": float(info.language_probability),
        "duration": float(info.duration),
        "model": args.model,
        "device": args.device,
        "compute_type": compute_type,
        "segments": segments,
    }
    out.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[OK] 转写完成: {out}  共 {len(segments)} 段, 时长={info.duration:.2f}s")
    return 0


if __name__ == "__main__":
    sys.exit(main())


# transcript.json schema:
# {
#   "audio_path": "...",
#   "language": "zh",
#   "language_probability": 0.99,
#   "duration": 123.4,
#   "model": "large-v3",
#   "segments": [
#     {
#       "id": 0,
#       "start": 1.23, "end": 4.56,
#       "text": "大家好今天分享一个技巧",
#       "confidence": 0.91,  // = mean(prob) over words
#       "avg_logprob": -0.34,
#       "no_speech_prob": 0.02,
#       "words": [
#         {"word": "大家好", "start": 1.23, "end": 1.85, "prob": 0.93},
#         ...
#       ]
#     }
#   ]
# }
