#!/usr/bin/env python3
"""Synthesize a fresh, restrained music/SFX bed from director_plan.json."""
from __future__ import annotations

import argparse
import json
import subprocess
import wave
from pathlib import Path
import numpy as np

SR = 48000


def tone(seconds, hz, decay=3.0, level=1.0):
    t = np.arange(int(seconds*SR), dtype=np.float32)/SR
    return (np.sin(2*np.pi*hz*t)*np.exp(-t*decay)*level).astype(np.float32)


def synth(plan, out: Path):
    profile = plan.get("music_profile") or {}
    style = profile.get("style")
    scores = {
        "focused_urgency": {"bpm": 96, "chords": [(110.0, 130.81, 164.81), (87.31, 110.0, 130.81), (98.0, 123.47, 146.83), (82.41, 103.83, 123.47)], "pulse": .011},
        "warm_encouragement": {"bpm": 82, "chords": [(130.81, 164.81, 196.0), (110.0, 130.81, 164.81), (146.83, 174.61, 220.0), (98.0, 123.47, 164.81)], "pulse": .009},
        "calm_explainer": {"bpm": 72, "chords": [(98.0, 146.83, 196.0), (110.0, 164.81, 220.0), (87.31, 130.81, 174.61), (98.0, 146.83, 196.0)], "pulse": .006},
    }
    if style not in scores or not profile.get("rationale"):
        raise ValueError("music_profile needs a supported style and content-specific rationale")
    score = scores[style]
    dur = plan["beats"][-1]["end"]
    n = int((dur+.1)*SR)
    t = np.arange(n, dtype=np.float32)/SR
    music = np.zeros(n, dtype=np.float32)
    # Content-selected procedural score. The plan chooses the score family;
    # this is not a stock-track search or licensed-music recommender.
    chords = score["chords"]
    beat_seconds = 60 / score["bpm"]
    for cidx, chord in enumerate(chords):
        block = beat_seconds * 8
        phase = (t % block) / block
        active = (t // block).astype(np.int32) % len(chords) == cidx
        amp = (0.006 + 0.002*np.sin(2*np.pi*phase))*active
        for freq in chord:
            music += (amp*np.sin(2*np.pi*freq*t)).astype(np.float32)
    # A restrained rhythmic pulse gives the score an audible musical bed.
    for pulse_t in np.arange(0, dur, beat_seconds):
        start = round(pulse_t*SR)
        pluck = tone(.24, 220.0 if style != "calm_explainer" else 164.81, 19, score["pulse"])
        music[start:start+len(pluck)] += pluck[:max(0,n-start)]
    music *= 4.5
    bed = music.copy()
    events = []
    for b in plan["beats"]:
        kind = b["sfx"]
        if kind == "none":
            continue
        start = int(b["start"]*SR)
        if kind == "opening":
            wavelet = tone(.45, 880, 8, .075) + tone(.45, 1320, 11, .03)
        elif kind == "tick":
            wavelet = tone(.11, 660, 31, .035)
        elif kind == "section":
            wavelet = tone(.42, 330, 7, .042) + tone(.42, 494, 9, .03)
        elif kind == "reveal":
            wavelet = tone(.25, 523, 11, .042) + tone(.25, 784, 17, .015)
        elif kind == "payoff":
            wavelet = tone(.72, 392, 5, .06) + tone(.72, 587, 6, .035)
        else:
            raise ValueError(f"unsupported sound event {kind}")
        bed[start:start+len(wavelet)] += wavelet[:max(0, n-start)]
        events.append({"beat":b["id"], "t":b["start"], "kind":kind})
    bed = np.clip(bed, -.18, .18)
    out.parent.mkdir(parents=True, exist_ok=True)
    write_wav(out, bed)
    write_wav(out.with_name("director_music_stem.wav"), music)
    return events


def write_wav(out, signal):
    stereo = np.stack((signal, signal*.96), axis=1)
    with wave.open(str(out), "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes((np.clip(stereo,-.99,.99)*32767).astype("<i2").tobytes())


def mix(video: Path, bed: Path, out: Path):
    cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", str(video), "-i", str(bed),
           "-filter_complex", "[0:a][1:a]amix=inputs=2:duration=first:dropout_transition=0,loudnorm=I=-14:TP=-1.5:LRA=11[a]",
           "-map", "0:v", "-map", "[a]", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest", str(out)]
    subprocess.run(cmd, check=True)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", type=Path, required=True)
    ap.add_argument("--plan", type=Path)
    ap.add_argument("--video", type=Path)
    ap.add_argument("--out", type=Path)
    a = ap.parse_args()
    project = a.project.resolve()
    plan_path = a.plan or project / "intermediate" / "director_plan.json"
    video = a.video or project / "output" / "final-director.mp4"
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    bed = project / "intermediate" / "director_original_score.wav"
    events = synth(plan, bed)
    out = a.out or project / "output" / "final-director-bgm.mp4"
    mix(video, bed, out)
    (project / "intermediate" / "director_sound_trace.json").write_text(
        json.dumps({"source":str(bed), "music_stem":str(bed.with_name("director_music_stem.wav")),
                    "video":str(video), "plan":str(plan_path), "output":str(out),
                    "music_profile":plan["music_profile"],
                    "events":events}, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[director] sound mix {out}, {len(events)} planned events")
