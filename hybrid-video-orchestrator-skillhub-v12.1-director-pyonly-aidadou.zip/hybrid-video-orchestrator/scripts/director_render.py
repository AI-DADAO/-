#!/usr/bin/env python3
"""Render a cut directly from a timed director plan and a newly cut source video.

The plan is the only source of route, staging, visual text and sound events.
No prior project's intermediate files are accepted as inputs.
"""
from __future__ import annotations

import argparse
import json
import math
import re
import subprocess
from pathlib import Path
from PIL import Image, ImageDraw, ImageEnhance, ImageFont
from font_paths import cjk_font

W, H, FPS = 720, 1280, 30
SAFE_TOP = 105
SAFE_RIGHT = 600
SUBTITLE_Y = 1002
MAIN_CENTER = W // 2
MAIN_LEFT = 120
FONT = cjk_font()
BOLD = cjk_font(bold=True)


def rgb(value: str):
    return tuple(bytes.fromhex(value.lstrip("#")))


def ffprobe(path: Path) -> float:
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                        "-of", "csv=p=0", str(path)], capture_output=True, text=True, check=True)
    return float(r.stdout.strip())


def parse_srt(path: Path):
    def sec(t):
        hh, mm, rest = t.split(":")
        ss, ms = rest.split(",")
        return int(hh)*3600 + int(mm)*60 + int(ss) + int(ms)/1000
    result = []
    for block in re.split(r"\n\s*\n", path.read_text(encoding="utf-8-sig").replace("\r", "\n")):
        lines = [x.strip() for x in block.splitlines() if x.strip()]
        if len(lines) < 3 or " --> " not in lines[1]:
            continue
        start, end = lines[1].split(" --> ")
        result.append((sec(start), sec(end), "".join(lines[2:])))
    return result


def validate(plan, duration):
    identity = plan.get("visual_identity") or {}
    if (identity.get("family") not in ("editorial", "ledger", "signal")
            or not identity.get("rationale")
            or len(identity.get("distinctive_compositions", [])) < 2
            or any(k not in plan.get("palette", {}) for k in ("ink", "paper", "accent", "mint"))):
        raise ValueError("plan requires project-specific visual_identity, two compositions, and a complete palette")
    beats = plan.get("beats", [])
    if len(beats) < max(3, math.ceil(duration/4)):
        raise ValueError("director plan needs micro beats, not only section rows")
    required = ("id", "start", "end", "cue", "intent", "takeaway", "task", "focus", "route", "layout", "headline", "sfx")
    visual_layouts = {"compare", "window", "abc_intro", "abc_focus", "abc_summary", "designed"}
    person_layouts = {"full", "full_rail", "full_callout", "split_list", "designed"}
    for i, beat in enumerate(beats):
        absent = [k for k in required if not beat.get(k) and beat.get(k) != 0]
        if absent:
            raise ValueError(f"{beat.get('id', i)} missing: {absent}")
        if beat["route"] not in ("PERSON", "PLAIN", "VISUAL"):
            raise ValueError(f"{beat['id']} invalid route")
        allowed = visual_layouts if beat["route"] == "VISUAL" else person_layouts
        if beat["layout"] not in allowed:
            raise ValueError(f"{beat['id']} unsupported {beat['route']} layout: {beat['layout']}")
        if beat["route"] == "VISUAL" and beat["layout"] != "designed" and not beat.get("visual"):
            raise ValueError(f"{beat['id']} missing visual data")
        if beat["layout"] == "designed":
            scene = beat.get("scene") or {}
            if not scene.get("id") or len(scene.get("elements", [])) < 2:
                raise ValueError(f"{beat['id']} designed scene needs id and at least two elements")
            for element in scene["elements"]:
                if element.get("type") not in {"text", "box", "line", "bar", "source_photo", "image"}:
                    raise ValueError(f"{beat['id']} unsupported scene element: {element.get('type')}")
        if beat["layout"] == "split_list" and not beat.get("items"):
            raise ValueError(f"{beat['id']} missing split-list items")
        if beat["end"] <= beat["start"]:
            raise ValueError(f"{beat['id']} invalid time window")
        if i and abs(beat["start"] - beats[i-1]["end"]) > 0.04:
            raise ValueError(f"gap or overlap: {beats[i-1]['id']} → {beat['id']}")
    if abs(beats[0]["start"]) > 0.01 or abs(beats[-1]["end"]-duration) > .20:
        raise ValueError("director plan does not cover the fresh cut")
    if len({b["id"] for b in beats}) != len(beats):
        raise ValueError("duplicate beat id")
    if plan.get("version", 2) >= 3:
        designed = [b for b in beats if b["layout"] == "designed"]
        if len(designed) < 2 or len({b["scene"]["id"] for b in designed}) < 2:
            raise ValueError("v3 plans need at least two distinct content-specific designed scenes")
        def geometry(scene):
            keys = ("x", "y", "w", "h", "x1", "y1", "x2", "y2", "size")
            return tuple((e["type"], *(round(float(e.get(k, -1000)) / 40) for k in keys))
                         for e in scene["elements"])
        if len({geometry(b["scene"]) for b in designed}) < 2:
            raise ValueError("v3 designed scenes must differ in visible composition, not only id or wording")
        if not identity.get("motif"):
            raise ValueError("v3 plans need a content-specific visual motif")
    return beats


def font(size, bold=False):
    return ImageFont.truetype(str(BOLD if bold else FONT), size=size)


def rounded(draw, box, fill, radius=20, outline=None, width=1):
    draw.rounded_rectangle(box, radius, fill=fill, outline=outline, width=width)


def text(draw, xy, s, size, color, bold=False, anchor=None):
    draw.text(xy, s, fill=color, font=font(size, bold), anchor=anchor,
              stroke_width=0)


def fit_text(draw, s, width, max_size, min_size=24, bold=True):
    for size in range(max_size, min_size-1, -2):
        if draw.textlength(s, font=font(size, bold)) <= width:
            return size
    return min_size


def palette(plan):
    p = plan.get("palette", {})
    return {k: rgb(p.get(k, v)) for k, v in {
        "ink":"#102433", "paper":"#F1EEE5", "accent":"#E67B5E", "mint":"#A6D6C4"}.items()}


def visual_base(p):
    img = Image.new("RGB", (W, H), p["ink"])
    d = ImageDraw.Draw(img, "RGBA")
    family = p["_family"]
    if family == "editorial":
        for i in range(7):
            y = 150 + i * 146
            d.line((44, y, 676, y), fill=(*p["paper"], 17), width=1)
        d.ellipse((500, -180, 1050, 370), outline=(*p["mint"], 26), width=2)
        d.ellipse((-400, 760, 260, 1420), outline=(*p["accent"], 22), width=2)
    elif family == "ledger":
        for i in range(9):
            y = 142 + i * 112
            d.line((38, y, 682, y), fill=(*p["paper"], 25), width=1)
            d.rectangle((48, y-5, 56, y+5), fill=(*p["accent"], 50))
        d.line((96, 145, 96, 1130), fill=(*p["mint"], 43), width=2)
    else:  # signal
        for i in range(8):
            x = -130 + i * 133
            d.line((x, 0, x+340, H), fill=(*p["mint"], 16), width=2)
        for x, y in ((86, 310), (625, 470), (80, 880), (595, 1050)):
            d.ellipse((x-4, y-4, x+4, y+4), fill=(*p["accent"], 72))
    return img


def source_base(src, p, beat):
    if beat["layout"].startswith("split_"):
        img = visual_base(p)
        # Crop from this run's cut, keeping the speaker large without masking hair.
        portrait = src.crop((70, 80, 650, 1070)).resize((280, 520), Image.Resampling.LANCZOS)
        portrait = ImageEnhance.Color(portrait).enhance(.78)
        img.paste(portrait, (120, 346))
        d = ImageDraw.Draw(img, "RGBA")
        d.rounded_rectangle((117, 343, 403, 871), radius=16, outline=(*p["mint"], 160), width=3)
        return img
    img = src.copy()
    img = ImageEnhance.Color(img).enhance(.78)
    ov = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    od = ImageDraw.Draw(ov, "RGBA")
    # Matching ink shadows across PLAIN and PERSON are the visual bridge to graphic shots.
    for y in range(0, 360, 4):
        a = round(170 * (1-y/360)**1.5)
        od.rectangle((0, y, W, y+4), fill=(*p["ink"], a))
    for y in range(860, H, 4):
        a = round(186 * ((y-860)/(H-860))**1.2)
        od.rectangle((0, y, W, y+4), fill=(*p["ink"], a))
    img = Image.alpha_composite(img.convert("RGBA"), ov).convert("RGB")
    return img


def camera_transform(src, beat, phase):
    """Apply the shot-specific reframing described by a PERSON/PLAIN beat."""
    move = beat.get("camera")
    if not move:
        return src
    z0,z1 = float(move.get("zoom_start",1)),float(move.get("zoom_end",1))
    if not (1 <= z0 <= 1.35 and 1 <= z1 <= 1.35):
        raise ValueError(f"{beat['id']} camera zoom must be 1.0–1.35")
    ease = phase*phase*(3-2*phase)
    zoom = z0+(z1-z0)*ease
    px = float(move.get("pan_x",0))
    py = float(move.get("pan_y",0))
    if abs(px) > .15 or abs(py) > .15:
        raise ValueError(f"{beat['id']} camera pan exceeds safe range")
    cw,ch = W/zoom,H/zoom
    cx,cy = W/2 + px*W,H/2 + py*H
    left = min(max(0,cx-cw/2),W-cw)
    top = min(max(0,cy-ch/2),H-ch)
    return src.crop((round(left),round(top),round(left+cw),round(top+ch))).resize(
        (W,H),Image.Resampling.BICUBIC)


def draw_header(img, beat, p, progress, visual=False):
    d = ImageDraw.Draw(img, "RGBA")
    route = beat["route"]
    tag = {"PERSON":"观点", "PLAIN":"行动", "VISUAL":"看懂"}[route]
    rounded(d, (42, SAFE_TOP+8, 116, SAFE_TOP+42), (*p["accent"], 240), 7)
    text(d, (79, SAFE_TOP+25), tag, 18, p["ink"], True, "mm")
    text(d, (130, SAFE_TOP+26), p["_series_label"], 18,
         (*p["paper"], 205), False, "lm")
    head = beat["headline"]
    size = fit_text(d, head, 555, 60 if visual else 48, 31)
    y = 209 if visual else 183
    x = 45 + int((1-progress)*24)
    text(d, (x, y), head, size, (*p["paper"], round(255*progress)), True, "lt")
    if beat.get("detail") and beat.get("layout") != "full_rail":
        # full_rail renders its detail inside the bottom rail; a header copy would duplicate it.
        text(d, (47, y+size+25), beat["detail"], 24,
             (*p["mint"], round(215*progress)), False, "lt")
    d.rectangle((42, SAFE_TOP-15, 42+int(548*min(1, max(0, beat["end"]/p["_total_duration"]))), SAFE_TOP-12), fill=p["accent"])
    return d


def draw_visual(img, beat, p, progress):
    d = draw_header(img, beat, p, progress, True)
    kind = beat["layout"]
    visual = beat["visual"]
    paper, accent, mint, ink = p["paper"], p["accent"], p["mint"], p["ink"]
    reveal = min(1, max(0, progress))
    if kind == "compare":
        rows = visual["rows"]
        if len(rows) != 3:
            raise ValueError("compare layout expects exactly 3 rows")
        colors = {"mint":mint, "accent":accent, "muted":(145,157,165)}
        for i, row in enumerate(rows):
            label, value, col = row["label"], row["value"], colors[row["tone"]]
            y = 364+i*142
            text(d, (MAIN_LEFT, y), label, 30, paper, False)
            rounded(d, (MAIN_LEFT, y+46, SAFE_RIGHT, y+112), (*paper, 20), 14)
            bar = max(10, int((460*value/100)*reveal))
            rounded(d, (MAIN_LEFT+5, y+51, MAIN_LEFT+5+bar, y+107), col, 10)
            text(d, (575, y+74), f"{value}", 35, ink if value else paper, True, "rm")
        rounded(d, (MAIN_LEFT, 840, SAFE_RIGHT, 915), (*accent, 235), 16)
        text(d, (MAIN_CENTER, 877), visual["conclusion"], fit_text(d, visual["conclusion"], 440, 31, 23), ink, True, "mm")
    elif kind == "window":
        count = int(visual["count"])
        if not 1 <= count <= 4:
            raise ValueError("window layout supports 1–4 units")
        text(d, (MAIN_LEFT, 382), visual["label"], 30, paper)
        cw = int((480-(count-1)*16)/count)
        for i in range(count):
            x = MAIN_LEFT+i*(cw+16)
            rounded(d, (x, 470, x+cw, 650), (*mint, 245) if i < round(reveal*count) else (*paper, 30), 18)
            text(d, (x+cw/2, 550), f"第{i+1}周", min(34, int(cw*.2)), ink if i < round(reveal*count) else paper, True, "mm")
        text(d, (MAIN_CENTER, 790), visual["conclusion"], fit_text(d, visual["conclusion"], 450, 35, 23), accent, True, "mm")
    elif kind == "abc_intro":
        cards = visual["cards"]
        if len(cards) != 3:
            raise ValueError("abc_intro expects 3 cards")
        for i, card in enumerate(cards):
            x = 122+i*165
            rounded(d, (x, 425, x+145, 712), (*paper, 235), 18)
            text(d, (x+72, 520), card["tag"], 88, ink, True, "mm")
            text(d, (x+72, 640), f"{card['pct']}%", 35, accent if i < 2 else ink, True, "mm")
        text(d, (MAIN_CENTER, 814), visual["conclusion"], fit_text(d, visual["conclusion"], 450, 32, 23), mint, True, "mm")
    elif kind == "abc_focus":
        focus, ratio, note = visual["tag"], f"{visual['pct']}%", visual["note"]
        variant = visual.get("variant", "card")
        if variant == "card":
            rounded(d, (MAIN_LEFT, 365, SAFE_RIGHT, 755), (*paper, 235), 24)
            text(d, (MAIN_CENTER, 510), focus, 150, accent, True, "mm")
            text(d, (MAIN_CENTER, 660), ratio, 75, ink, True, "mm")
            text(d, (MAIN_CENTER, 835), note, 32, mint, True, "mm")
        elif variant == "rail":
            text(d, (155, 560), focus, 192, mint, True, "mm")
            d.line((275, 420, 275, 690), fill=(*paper, 100), width=3)
            text(d, (300, 515), ratio, 103, accent, True, "lm")
            rounded(d, (300, 595, 590, 633), (*paper, 32), 12)
            rounded(d, (300, 595, 300+int(290*visual["pct"]/100), 633), accent, 12)
            text(d, (MAIN_CENTER, 815), note, 32, paper, True, "mm")
        elif variant == "baseline":
            text(d, (MAIN_CENTER, 490), focus, 175, (*paper, 175), True, "mm")
            d.line((MAIN_LEFT, 620, SAFE_RIGHT, 620), fill=(*mint, 160), width=3)
            text(d, (MAIN_CENTER, 724), ratio, 95, accent, True, "mm")
            text(d, (MAIN_CENTER, 850), note, 32, mint, True, "mm")
        else:
            raise ValueError(f"unsupported abc_focus variant: {variant}")
    elif kind == "abc_summary":
        text(d, (MAIN_CENTER, 415), visual["top"], fit_text(d, visual["top"], 450, 80, 35), mint, True, "mm")
        text(d, (MAIN_CENTER, 605), visual["main"], fit_text(d, visual["main"], 450, 150, 60), accent, True, "mm")
        text(d, (MAIN_CENTER, 795), visual["bottom"], fit_text(d, visual["bottom"], 450, 31, 23), paper, True, "mm")
        d.line((150, 865, 570, 865), fill=(*mint, 180), width=3)
    return img


def draw_source(img, beat, p, progress):
    d = draw_header(img, beat, p, progress)
    if beat["layout"] == "split_list":
        items = beat["items"]
        if not 1 <= len(items) <= 3:
            raise ValueError("split_list supports 1–3 items")
        for i, label in enumerate(items):
            num = f"{i+1:02d}" if len(items) > 1 else "10×"
            y = 423 + i*145 if len(items) > 1 else 578
            rounded(d, (410, y-26, SAFE_RIGHT, y+89), (*p["paper"], 235), 15)
            text(d, (425, y), num, 41 if len(items)==3 else 61, p["accent"], True, "lt")
            text(d, (425, y+60), label, fit_text(d, label, 160, 21, 17), p["ink"], True, "lt")
        return img
    if beat["layout"] == "full_rail":
        # One information rail, never over the speaker's face.
        detail = beat.get("detail", "")
        rounded(d, (45, 870, 595, 950), (*p["ink"], 216), 14,
                (*p["mint"], 90), 1)
        text(d, (320, 910), detail, fit_text(d, detail, 500, 27, 19), p["paper"], True, "mm")
    if beat["layout"] == "full_callout":
        rounded(d, (45, 850, 440, 925), (*p["ink"], 205), 12)
        d.rectangle((45, 850, 52, 925), fill=p["accent"])
        text(d, (70, 887), beat["callout"], fit_text(d, beat["callout"], 335, 29, 23), p["paper"], True, "lm")
    return img


def scene_color(value, p, default="paper"):
    value = value or default
    if value in p:
        return p[value]
    if isinstance(value, str) and re.fullmatch(r"#[0-9a-fA-F]{6}", value):
        return rgb(value)
    raise ValueError(f"unsupported scene color: {value}")


def draw_designed(img, src, beat, p, progress):
    """Draw a beat-specific composition from the plan rather than a fixed card."""
    scene = beat["scene"]
    d = ImageDraw.Draw(img, "RGBA")
    if scene.get("header", "none") == "standard":
        draw_header(img, beat, p, progress, beat["route"] == "VISUAL")
    for element in scene["elements"]:
        kind = element["type"]
        motion = element.get("motion", "none")
        amount = progress if motion in {"fade", "rise", "draw"} else 1.0
        dy = int((1-progress)*32) if motion == "rise" else 0
        fill = scene_color(element.get("color"), p)
        alpha = round(255*amount)
        if kind == "box":
            x,y,w,h = (int(element[k]) for k in ("x","y","w","h"))
            d.rounded_rectangle((x,y+dy,x+w,y+h+dy),radius=int(element.get("radius",12)),
                                fill=(*fill,alpha))
        elif kind == "line":
            x1,y1,x2,y2 = (int(element[k]) for k in ("x1","y1","x2","y2"))
            if motion == "draw":
                x2 = round(x1+(x2-x1)*progress)
                y2 = round(y1+(y2-y1)*progress)
            d.line((x1,y1+dy,x2,y2+dy),fill=(*fill,alpha),width=int(element.get("width",3)))
        elif kind == "bar":
            x,y,w,h = (int(element[k]) for k in ("x","y","w","h"))
            value = max(0.0,min(1.0,float(element.get("value",0))/max(1,float(element.get("max",100)))))
            d.rounded_rectangle((x,y+dy,x+w,y+h+dy),radius=min(12,h//2),fill=(*p["paper"],35))
            d.rounded_rectangle((x,y+dy,x+max(1,round(w*value*amount)),y+h+dy),
                                radius=min(12,h//2),fill=(*fill,alpha))
        elif kind == "image":
            # External still (e.g. a screenshot supplied for this project). Cropped in source pixels.
            x,y,w,h = (int(element[k]) for k in ("x","y","w","h"))
            image = p["_images"].get((beat["id"], element.get("path")))
            if image is None:
                raise ValueError(f"{beat['id']} image element was not preloaded: {element.get('path')}")
            crop = element.get("crop")
            region = image
            if crop:
                if len(crop) != 4:
                    raise ValueError("image crop must be [left,top,right,bottom]")
                region = image.crop(tuple(int(v) for v in crop))
            photo = region.resize((w,h), Image.Resampling.LANCZOS)
            if amount < 1:
                veil = Image.new("RGB", photo.size, p["ink"])
                photo = Image.blend(veil, photo, amount)
            img.paste(photo, (x, y+dy))
            d = ImageDraw.Draw(img, "RGBA")
            if element.get("border"):
                d.rounded_rectangle((x, y+dy, x+w, y+h+dy), radius=int(element.get("radius", 0)),
                                    outline=(*scene_color(element.get("border"), p), 220), width=3)
        elif kind == "text":
            value = str(element.get("text", ""))
            if not value:
                raise ValueError(f"{beat['id']} empty designed text")
            x,y = int(element["x"]),int(element["y"])
            width = int(element.get("max_width",W-x-45))
            size = fit_text(d,value,width,int(element.get("size",52)),int(element.get("min_size",22)),
                            bool(element.get("bold",True)))
            d.text((x,y+dy),value,fill=(*fill,alpha),font=font(size,bool(element.get("bold",True))),
                   anchor=element.get("anchor","lt"))
        elif kind == "source_photo":
            x,y,w,h = (int(element[k]) for k in ("x","y","w","h"))
            crop = element.get("crop",[45,90,630,1100])
            if len(crop)!=4:
                raise ValueError("source_photo crop must be [left,top,right,bottom]")
            photo = src.crop(tuple(int(v) for v in crop)).resize((w,h),Image.Resampling.LANCZOS)
            if amount < 1:
                veil = Image.new("RGB",photo.size,p["ink"])
                photo = Image.blend(veil,photo,amount)
            img.paste(photo,(x,y+dy))
            d = ImageDraw.Draw(img,"RGBA")
            d.rounded_rectangle((x,y+dy,x+w,y+h+dy),radius=int(element.get("radius",0)),
                                outline=(*scene_color(element.get("border","mint"),p),210),width=3)
    return img


def subtitle_at(cues, t):
    for a, b, s in cues:
        if a <= t < b:
            # Preserve one line by rotating contiguous clauses inside the original cue window.
            chunks = [s[i:i+16] for i in range(0, len(s), 16)] or [""]
            pos = min(len(chunks)-1, int((t-a)/(b-a)*len(chunks)))
            return chunks[pos]
    return ""


def draw_subtitle(img, s, p):
    if not s:
        return
    d = ImageDraw.Draw(img, "RGBA")
    size = fit_text(d, s, 440, 34, 27)
    tw = d.textlength(s, font=font(size, True))
    cx = MAIN_CENTER
    x0, x1 = int(cx-tw/2)-20, int(cx+tw/2)+20
    rounded(d, (x0, SUBTITLE_Y, x1, SUBTITLE_Y+58), (*p["ink"], 227), 12)
    text(d, (cx, SUBTITLE_Y+29), s, size, p["paper"], True, "mm")


def write_sfx(plan, target):
    events = []
    for b in plan["beats"]:
        if b["sfx"] != "none":
            events.append({"beat":b["id"], "t":b["start"], "kind":b["sfx"]})
    target.write_text(json.dumps({"events":events}, ensure_ascii=False, indent=2), encoding="utf-8")


def render(project: Path, plan_path: Path, out: Path, source: Path, srt: Path):
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    duration = ffprobe(source)
    beats = validate(plan, duration)
    cues = parse_srt(srt)
    if not cues:
        raise ValueError("fresh SRT has no cues")
    p = palette(plan)
    p["_family"] = plan["visual_identity"]["family"]
    p["_series_label"] = plan.get("series_label", "口播 / NOTES")
    p["_total_duration"] = beats[-1]["end"]
    p["_images"] = {}
    for beat in beats:
        for element in (beat.get("scene") or {}).get("elements", []):
            if element.get("type") == "image":
                path = (project / element["path"]).resolve()
                if not path.is_file():
                    raise ValueError(f"{beat['id']} image element not found: {path}")
                key = (beat["id"], element.get("path"))
                if key not in p["_images"]:
                    p["_images"][key] = Image.open(path).convert("RGB")
    out.parent.mkdir(parents=True, exist_ok=True)
    (project / "intermediate").mkdir(parents=True, exist_ok=True)
    decode = subprocess.Popen(["ffmpeg", "-hide_banner", "-loglevel", "error", "-i", str(source),
                               "-f", "rawvideo", "-pix_fmt", "rgb24", "-vf", f"scale={W}:{H}", "-"], stdout=subprocess.PIPE)
    encode = subprocess.Popen(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-f", "rawvideo",
                               "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                               "-i", str(source), "-map", "0:v", "-map", "1:a", "-c:v", "libx264",
                               "-preset", "veryfast", "-crf", "17", "-vf", "scale=1080:1920",
                               "-c:a", "aac", "-b:a", "192k", "-shortest", str(out)], stdin=subprocess.PIPE)
    frame_bytes = W*H*3
    count = round(min(beats[-1]["end"], duration)*FPS)
    bidx = 0
    previous_beat = None
    trace = []
    try:
        for f in range(count):
            t = f/FPS
            while bidx + 1 < len(beats) and t >= beats[bidx]["end"] - 1e-7:
                bidx += 1
            beat = beats[bidx]
            raw = decode.stdout.read(frame_bytes)
            if len(raw) != frame_bytes:
                raise RuntimeError(f"fresh source ended at frame {f}; no prior render fallback")
            src = Image.frombytes("RGB", (W, H), raw)
            progress = min(1, (t-beat["start"])/.33)
            phase = min(1,max(0,(t-beat["start"])/max(.001,beat["end"]-beat["start"])))
            if beat["route"] != "VISUAL":
                src = camera_transform(src,beat,phase)
            if beat["route"] == "VISUAL":
                img = visual_base(p)
                if beat["layout"] == "designed":
                    draw_designed(img,src,beat,p,progress)
                else:
                    draw_visual(img, beat, p, progress)
            else:
                img = source_base(src, p, beat)
                if beat["layout"] == "designed":
                    draw_designed(img,src,beat,p,progress)
                else:
                    draw_source(img, beat, p, progress)
            draw_subtitle(img, subtitle_at(cues, t), p)
            encode.stdin.write(img.tobytes())
            if beat["id"] != previous_beat:
                trace.append({"beat":beat["id"], "frame":f, "route":beat["route"],
                              "focus":beat["focus"], "layout":beat["layout"],
                              "headline":beat["headline"], "takeaway":beat["takeaway"],
                              "visual":beat.get("visual"), "items":beat.get("items"),
                              "callout":beat.get("callout"),
                              "scene":beat.get("scene")})
                previous_beat = beat["id"]
            if f % 300 == 0:
                print(f"[director] {f}/{count} frames", flush=True)
    finally:
        if encode.stdin:
            encode.stdin.close()
        if decode.stdout:
            decode.stdout.close()
    if decode.wait() != 0 or encode.wait() != 0:
        raise RuntimeError("ffmpeg decode/encode failed")
    (project / "intermediate" / "director_render_trace.json").write_text(
        json.dumps({"source":str(source), "srt":str(srt), "plan":str(plan_path), "output":str(out),
                    "visual_identity":plan["visual_identity"], "canvas_center_x":MAIN_CENTER,
                    "frames":count, "beats":trace},
                   ensure_ascii=False, indent=2), encoding="utf-8")
    write_sfx(plan, project / "intermediate" / "director_sfx_events.json")
    print(f"[director] rendered {out} ({ffprobe(out):.2f}s)")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", type=Path, required=True)
    ap.add_argument("--plan", type=Path)
    ap.add_argument("--out", type=Path)
    ap.add_argument("--source", type=Path)
    ap.add_argument("--srt", type=Path)
    a = ap.parse_args()
    project = a.project.resolve()
    render(project, a.plan or project / "intermediate" / "director_plan.json",
           a.out or project / "output" / "final-director.mp4",
           a.source or project / "output" / "final.mp4",
           a.srt or project / "output" / "final.srt")
