#!/usr/bin/env python3
"""Check media and trace contracts for online-library BGM and a one-frame cover."""
from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path


def probe(path: Path, entry: str) -> float:
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", entry,
                        "-of", "csv=p=0", str(path)], check=True, capture_output=True, text=True)
    return float(r.stdout.strip())


def main():
    ap = argparse.ArgumentParser()
    for name in ("project", "plan", "rendered", "mixed", "delivered"):
        ap.add_argument(f"--{name}", required=True, type=Path)
    a = ap.parse_args()
    project = a.project.resolve()
    plan = json.loads(a.plan.read_text(encoding="utf-8"))
    music = json.loads((project / "intermediate" / "online_bgm_trace.json").read_text(encoding="utf-8"))
    cover = json.loads((project / "intermediate" / "cover_intro_trace.json").read_text(encoding="utf-8"))
    checks = {
        "online_track_input": Path(music["source_video"]).resolve() == a.rendered.resolve(),
        "online_track_output": Path(music["output"]).resolve() == a.mixed.resolve(),
        "music_below_active_voice": (music["voice_active_dbfs"] -
                                     (music["music_original_dbfs"] + music["music_gain_db"])) >= 17.5,
        "one_cover_frame": cover["cover_frames"] == 1 and
                           cover["delivered_frames"] == cover["source_frames"] + 1,
        "cover_input": Path(cover["input"]).resolve() == a.mixed.resolve(),
        "cover_output": Path(cover["output"]).resolve() == a.delivered.resolve(),
        "cover_style": plan.get("cover", {}).get("style") == "creator_collage",
    }
    source_seconds = probe(a.rendered, "format=duration")
    mixed_seconds = probe(a.mixed, "format=duration")
    delivered_seconds = probe(a.delivered, "format=duration")
    checks["durations"] = (abs(source_seconds - mixed_seconds) < .12 and
                           abs(delivered_seconds - mixed_seconds - 1/30) < .12)
    stream = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "a:0",
                             "-show_entries", "stream=codec_name", "-of", "csv=p=0",
                             str(a.delivered)], check=True, capture_output=True, text=True)
    checks["audio_present"] = bool(stream.stdout.strip())
    if plan.get("version", 2) >= 3:
        render_trace = json.loads((project / "intermediate" / "director_render_trace.json").read_text(encoding="utf-8"))
        expected = [(b["id"], b.get("scene")) for b in plan["beats"]]
        actual = [(b["beat"], b.get("scene")) for b in render_trace["beats"]]
        designed = [b for b in plan["beats"] if b["layout"] == "designed"]
        checks["designed_scenes_executed"] = expected == actual and len(designed) >= 2
        checks["distinct_compositions"] = len({b["scene"]["id"] for b in designed}) >= 2
        def geometry(scene):
            keys = ("x", "y", "w", "h", "x1", "y1", "x2", "y2", "size")
            return tuple((e["type"], *(round(float(e.get(k, -1000)) / 40) for k in keys))
                         for e in scene["elements"])
        checks["distinct_scene_geometry"] = len({geometry(b["scene"]) for b in designed}) >= 2
        visual = [b["layout"] for b in plan["beats"] if b["route"] == "VISUAL"]
        checks["visual_layout_variety"] = len(visual) < 3 or len(set(visual)) >= 2
    report = {"checks": checks, "pass": all(checks.values()),
              "human_review_still_required": ["track-specific license", "voice/music listening",
                                              "cover thumbnail", "platform safe area", "pause cuts"]}
    target = project / "intermediate" / "online_qc_report.json"
    target.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
