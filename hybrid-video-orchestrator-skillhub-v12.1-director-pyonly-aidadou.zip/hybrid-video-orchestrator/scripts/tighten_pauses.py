#!/usr/bin/env python3
"""Audit and remove reviewed silent pauses before visual rendering.

Outputs a fresh cut, retimed SRT and retimed director plan. The cut list is
reviewed data, never guessed from subtitles or image transitions alone.
"""
from __future__ import annotations

import argparse
import json
import math
import re
import subprocess
from pathlib import Path
import numpy as np

SR = 16000
FPS = 30


def audio(path):
    raw = subprocess.check_output(["ffmpeg", "-v", "error", "-i", str(path), "-vn",
                                   "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"])
    return np.frombuffer(raw, dtype=np.float32)


def dur(path):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                        "-of", "csv=p=0", str(path)], capture_output=True, text=True, check=True)
    return float(r.stdout.strip())


def candidates(signal):
    hop = int(SR*.01)
    frame = int(SR*.03)
    rms = np.array([np.sqrt(np.mean(signal[i:i+frame]**2)+1e-16)
                    for i in range(0, len(signal)-frame, hop)])
    quiet = rms < 10**(-34/20)
    spans = []
    start = None
    for i, flag in enumerate(quiet):
        if flag and start is None:
            start = i
        if start is not None and (not flag or i == len(quiet)-1):
            end = i
            if (end-start)*.01 >= .18:
                spans.append({"start":round(start*.01, 3), "end":round(end*.01, 3),
                              "duration":round((end-start)*.01, 3)})
            start = None
    return spans


def read_srt(path):
    def seconds(ts):
        hh, mm, rest = ts.split(":")
        ss, ms = rest.split(",")
        return int(hh)*3600 + int(mm)*60 + int(ss) + int(ms)/1000
    cues=[]
    content=path.read_text(encoding="utf-8-sig").replace("\r", "\n")
    for block in re.split(r"\n\s*\n", content):
        lines=[x.strip() for x in block.splitlines() if x.strip()]
        if len(lines)>=3 and " --> " in lines[1]:
            a,b=lines[1].split(" --> ")
            cues.append((seconds(a),seconds(b),"".join(lines[2:])))
    return cues


def srt_time(t):
    ms=round(t*1000)
    return f"{ms//3600000:02d}:{(ms//60000)%60:02d}:{(ms//1000)%60:02d},{ms%1000:03d}"


def map_time(t, cuts):
    removed=0.0
    for a,b in cuts:
        if t>=b:
            removed+=b-a
        elif t>a:
            removed+=t-a
            break
        else:
            break
    return round(max(0,t-removed), 6)


def render_cut(source, cuts, target):
    end=dur(source)
    keeps=[]
    cursor=0.0
    for a,b in cuts:
        keeps.append((cursor,a))
        cursor=b
    keeps.append((cursor,end))
    parts=[]
    tags=[]
    for i,(a,b) in enumerate(keeps):
        parts.append(f"[0:v]trim=start={a:.6f}:end={b:.6f},setpts=PTS-STARTPTS[v{i}]")
        parts.append(f"[0:a]atrim=start={a:.6f}:end={b:.6f},asetpts=PTS-STARTPTS[a{i}]")
        tags.append(f"[v{i}][a{i}]")
    graph=";".join(parts)+";"+"".join(tags)+f"concat=n={len(keeps)}:v=1:a=1[v][a]"
    target.parent.mkdir(parents=True,exist_ok=True)
    subprocess.run(["ffmpeg","-y","-hide_banner","-loglevel","error","-i",str(source),
                    "-filter_complex",graph,"-map","[v]","-map","[a]","-r",str(FPS),
                    "-c:v","libx264","-preset","veryfast","-crf","17","-pix_fmt","yuv420p",
                    "-c:a","aac","-b:a","192k",str(target)],check=True)


def run(project, cuts_path):
    source=project/"output"/"final.mp4"
    signal=audio(source)
    suggestions=candidates(signal)
    (project/"intermediate"/"pause_candidates.json").write_text(
        json.dumps({"source":str(source),"candidates":suggestions},ensure_ascii=False,indent=2),encoding="utf-8")
    if cuts_path is None:
        print(f"[pauses] {len(suggestions)} candidates; review pause_candidates.json, then provide --cuts")
        return
    spec=json.loads(cuts_path.read_text(encoding="utf-8"))
    cuts=[]
    for entry in spec["cuts"]:
        a,b=float(entry["start"]),float(entry["end"])
        if a<0 or b<=a or b>dur(source):
            raise ValueError(f"invalid cut {a}-{b}")
        if abs(a*FPS-round(a*FPS))>.003 or abs(b*FPS-round(b*FPS))>.003:
            raise ValueError(f"cut must align to video frames: {a}-{b}")
        sample=signal[round(a*SR):round(b*SR)]
        db=20*math.log10(float(np.sqrt(np.mean(sample**2)))+1e-12)
        if db>-30:
            raise ValueError(f"cut contains likely speech ({db:.1f} dB RMS): {a}-{b}")
        cuts.append((a,b))
    cuts.sort()
    if any(a2<b1 for (_,b1),(a2,_) in zip(cuts,cuts[1:])):
        raise ValueError("overlapping pause cuts")
    if sum(b-a for a,b in cuts) > 2.0:
        raise ValueError("pause removal exceeds 2 s; review manually")
    video=project/"output"/"final-tight.mp4"
    render_cut(source,cuts,video)
    cues=read_srt(project/"output"/"final.srt")
    lines=[]
    for i,(a,b,s) in enumerate(cues,1):
        na,nb=map_time(a,cuts),map_time(b,cuts)
        if nb-na<.15:
            raise ValueError(f"subtitle cue {i} collapsed after cuts")
        lines.extend([str(i),f"{srt_time(na)} --> {srt_time(nb)}",s,""])
    (project/"output"/"final-tight.srt").write_text("\n".join(lines),encoding="utf-8")
    plan_path=project/"intermediate"/"director_plan.json"
    if plan_path.exists():
        plan=json.loads(plan_path.read_text(encoding="utf-8"))
        for beat in plan["beats"]:
            beat["start"]=map_time(beat["start"],cuts)
            beat["end"]=map_time(beat["end"],cuts)
        plan["duration"]=map_time(plan["duration"],cuts)
        (project/"intermediate"/"director_plan-tight.json").write_text(
            json.dumps(plan,ensure_ascii=False,indent=2),encoding="utf-8")
    report={"source":str(source),"output":str(video),"cuts":[{"start":a,"end":b,"removed":round(b-a,3)} for a,b in cuts],
            "total_removed":round(sum(b-a for a,b in cuts),3),"new_duration":dur(video)}
    (project/"intermediate"/"pause_report.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    print(f"[pauses] removed {report['total_removed']:.3f}s in {len(cuts)} cuts; final {report['new_duration']:.3f}s")


if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--project",type=Path,required=True)
    ap.add_argument("--cuts",type=Path)
    a=ap.parse_args()
    run(a.project.resolve(),a.cuts.resolve() if a.cuts else None)
