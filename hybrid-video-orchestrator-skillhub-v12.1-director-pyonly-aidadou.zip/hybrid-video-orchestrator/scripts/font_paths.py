"""Resolve installed CJK fonts without tying a sold Skill to one Windows user."""
from __future__ import annotations

import os
from pathlib import Path


def cjk_font(bold: bool = False) -> Path:
    override = os.environ.get("HVO_BOLD_FONT" if bold else "HVO_REGULAR_FONT")
    candidates = [
        override,
        r"C:\Windows\Fonts\msyhbd.ttc" if bold else r"C:\Windows\Fonts\msyh.ttc",
        r"C:\Windows\Fonts\simhei.ttf" if bold else r"C:\Windows\Fonts\simsun.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc" if bold else "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/truetype/noto/NotoSansCJK-Bold.ttc" if bold else "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc",
        "/System/Library/Fonts/PingFang.ttc",
    ]
    for candidate in candidates:
        if candidate and Path(candidate).is_file():
            return Path(candidate)
    label = "HVO_BOLD_FONT" if bold else "HVO_REGULAR_FONT"
    raise FileNotFoundError(f"No CJK font found; set {label} to an installed CJK font")
