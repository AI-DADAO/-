#!/usr/bin/env python3
"""Launch one approved Director Mode tool with the installed runtime."""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path


TOOLS = {
    "preflight", "raw_pipeline", "tighten_pauses", "director_render",
    "director_sound", "director_qc", "online_bgm", "cover_intro", "online_qc",
}
ROOT = Path(__file__).resolve().parent.parent
RUNTIME_FILE = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local")) / "HVO" / "v11" / "runtime.json"


def main() -> int:
    if len(sys.argv) < 2 or sys.argv[1] not in TOOLS:
        print("Usage: python scripts/runner.py <tool> [arguments]", file=sys.stderr)
        return 2
    if not RUNTIME_FILE.is_file():
        print("Runtime missing; run scripts/bootstrap.py first.", file=sys.stderr)
        return 2
    config = json.loads(RUNTIME_FILE.read_text(encoding="utf-8"))
    python = Path(config["python"])
    script = ROOT / "scripts" / f"{sys.argv[1]}.py"
    if not python.is_file() or not script.is_file():
        print("Installed Python or tool script is missing.", file=sys.stderr)
        return 2
    env = os.environ.copy()
    env["PATH"] = str(config["ffmpeg_bin"]) + os.pathsep + env.get("PATH", "")
    env["HF_HOME"] = str(config["hf_home"])
    env["PYTHONUTF8"] = "1"
    return subprocess.run([str(python), str(script), *sys.argv[2:]], env=env, check=False).returncode


if __name__ == "__main__":
    raise SystemExit(main())
