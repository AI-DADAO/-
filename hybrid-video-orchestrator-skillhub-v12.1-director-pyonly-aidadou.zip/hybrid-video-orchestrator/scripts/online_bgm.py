#!/usr/bin/env python3
"""Mix a separately downloaded, licensed stock track below the spoken voice.

The music file is a per-project input, never an asset bundled with a sold Skill.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import subprocess
import wave
from pathlib import Path
from urllib.parse import urlparse

import numpy as np

SR = 48000


def tone(seconds, hz, decay=3.0, level=1.0):
    t = np.arange(int(seconds * SR), dtype=np.float32) / SR
    return (np.sin(2 * np.pi * hz * t) * np.exp(-t * decay) * level).astype(np.float32)


def duration(path: Path) -> float:
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                        "-of", "csv=p=0", str(path)], check=True, capture_output=True, text=True)
    return float(r.stdout.strip())


def samples(path: Path, seconds: float) -> np.ndarray:
    r = subprocess.run(["ffmpeg", "-v", "error", "-i", str(path), "-t", str(seconds),
                        "-vn", "-ac", "1", "-ar", "16000", "-f", "f32le", "-"],
                       check=True, capture_output=True)
    return np.frombuffer(r.stdout, dtype="<f4")


def rms_db(x: np.ndarray, voice=False) -> float:
    if voice:
        frames = x[:len(x)//320*320].reshape(-1,320)
        levels = np.sqrt(np.mean(frames*frames, axis=1)+1e-12)
        active = levels > .0063  # about -44 dBFS; reject quiet breath/silence
        x = frames[active].ravel()
    if x.size == 0:
        raise ValueError("no active voice or decodable music")
    return 20*math.log10(float(np.sqrt(np.mean(x*x)))+1e-12)


def make_sfx(plan: dict, target: Path, seconds: float):
    n = round(seconds*SR)
    bed = np.zeros(n, dtype=np.float32)
    events=[]
    for beat in plan["beats"]:
        kind=beat["sfx"]
        if kind == "none":
            continue
        if kind == "opening":
            sound=tone(.45,880,8,.075)+tone(.45,1320,11,.03)
        elif kind == "tick":
            sound=tone(.11,660,31,.035)
        elif kind == "section":
            sound=tone(.42,330,7,.042)+tone(.42,494,9,.03)
        elif kind == "reveal":
            sound=tone(.25,523,11,.042)+tone(.25,784,17,.015)
        elif kind == "payoff":
            sound=tone(.72,392,5,.06)+tone(.72,587,6,.035)
        else:
            raise ValueError(f"unsupported sfx: {kind}")
        start=round(float(beat["start"])*SR)
        end=min(n,start+len(sound))
        if start<n:
            bed[start:end]+=sound[:end-start]
        events.append({"beat":beat["id"],"t":beat["start"],"kind":kind})
    target.parent.mkdir(parents=True,exist_ok=True)
    with wave.open(str(target),"wb") as w:
        w.setnchannels(2);w.setsampwidth(2);w.setframerate(SR)
        stereo=np.stack((bed,bed*.96),axis=1)
        w.writeframes((np.clip(stereo,-.95,.95)*32767).astype("<i2").tobytes())
    return events


def run(project:Path, plan_path:Path, video:Path, track:Path, evidence_path:Path, out:Path):
    (project/"intermediate").mkdir(parents=True,exist_ok=True)
    plan=json.loads(plan_path.read_text(encoding="utf-8"))
    evidence=json.loads(evidence_path.read_text(encoding="utf-8"))
    for key in ("title","artist","page_url","license_url","source","downloaded_at"):
        if not evidence.get(key):
            raise ValueError(f"music evidence missing {key}")
    music_hosts={"mixkit.co","www.mixkit.co","pixabay.com","www.pixabay.com",
                 "incompetech.com","www.incompetech.com"}
    license_hosts=music_hosts|{"creativecommons.org","www.creativecommons.org"}
    page=urlparse(evidence["page_url"])
    license_page=urlparse(evidence["license_url"])
    if page.scheme != "https" or page.hostname not in music_hosts:
        raise ValueError("music page must point to an official HTTPS track page")
    if license_page.scheme != "https" or license_page.hostname not in license_hosts:
        raise ValueError("license page must point to an official HTTPS music or Creative Commons page")
    page_path = urlparse(evidence["page_url"]).path.rstrip("/")
    if page_path in ("", "/free-stock-music", "/music"):
        raise ValueError("music page_url must be an official page displaying the selected track, not the library home page")
    if not track.is_file() or track.stat().st_size < 100_000:
        raise ValueError("download the selected track from its official page into this project first")
    seconds=duration(video)
    if duration(track)<seconds-1:
        raise ValueError("track is shorter than the video; choose another track or an intentional loop point")
    voice_db=rms_db(samples(video,seconds),voice=True)
    music_db=rms_db(samples(track,seconds))
    gap_db=18.0
    gain_db=min(0.0,voice_db-gap_db-music_db)
    gain=10**(gain_db/20)
    sfx=project/"intermediate"/"online_sfx_stem.wav"
    events=make_sfx(plan,sfx,seconds)
    fade_out=max(0.0,seconds-.85)
    fg=(f"[0:a]asplit=2[voice][key];"
        f"[1:a]atrim=duration={seconds:.6f},aresample=48000,"
        f"volume={gain:.8f},afade=t=in:st=0:d=0.35,"
        f"afade=t=out:st={fade_out:.6f}:d=0.8[music];"
        f"[music][key]sidechaincompress=threshold=0.025:ratio=4:attack=20:release=250[duck];"
        f"[voice][duck][2:a]amix=inputs=3:duration=first:normalize=0,"
        f"loudnorm=I=-14:TP=-1.5:LRA=11[a]")
    out.parent.mkdir(parents=True,exist_ok=True)
    subprocess.run(["ffmpeg","-y","-hide_banner","-loglevel","error",
                    "-i",str(video),"-i",str(track),"-i",str(sfx),
                    "-filter_complex",fg,"-map","0:v","-map","[a]",
                    "-c:v","copy","-c:a","aac","-b:a","192k","-shortest",str(out)],check=True)
    sha=hashlib.sha256(track.read_bytes()).hexdigest()
    trace={"source_video":str(video.resolve()),"music_file":str(track.resolve()),
           "music_sha256":sha,"evidence":evidence,"voice_active_dbfs":round(voice_db,2),
           "music_original_dbfs":round(music_db,2),"music_gain_db":round(gain_db,2),
           "target_gap_db":gap_db,"sfx_events":events,"output":str(out.resolve())}
    (project/"intermediate"/"online_bgm_trace.json").write_text(
        json.dumps(trace,ensure_ascii=False,indent=2),encoding="utf-8")
    print(f"[online-bgm] {evidence['title']} / {evidence['artist']}; voice {voice_db:.1f} dBFS, "
          f"music {music_db+gain_db:.1f} dBFS before speech ducking; {out}")


if __name__=="__main__":
    ap=argparse.ArgumentParser()
    for name in ("project","plan","video","track","evidence","out"):
        ap.add_argument(f"--{name}",type=Path,required=True)
    a=ap.parse_args()
    run(a.project.resolve(),a.plan.resolve(),a.video.resolve(),a.track.resolve(),
        a.evidence.resolve(),a.out.resolve())
