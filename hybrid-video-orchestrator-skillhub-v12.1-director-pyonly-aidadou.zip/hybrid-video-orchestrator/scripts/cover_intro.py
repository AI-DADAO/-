#!/usr/bin/env python3
"""Compose a project-specific AI cover and prepend exactly one video frame."""
from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageOps
from font_paths import cjk_font

W, H, FPS = 1080, 1920, 30
FONT = cjk_font(bold=True)


def probe_frames(path: Path) -> int:
    r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0",
                        "-count_frames", "-show_entries", "stream=nb_read_frames",
                        "-of", "csv=p=0", str(path)], check=True, capture_output=True, text=True)
    return int(r.stdout.strip().split(',')[0])


def fit(draw, content, maximum, width):
    while maximum > 32 and draw.textlength(content, font=ImageFont.truetype(str(FONT), maximum)) > width:
        maximum -= 2
    return ImageFont.truetype(str(FONT), maximum)


def compose(art: Path, plan: dict, target: Path):
    cover = plan.get("cover") or {}
    lines = cover.get("title_lines") or []
    if (cover.get("duration_frames") != 1 or len(lines) != 2
            or not cover.get("eyebrow") or not cover.get("subline")
            or not cover.get("art_prompt")):
        raise ValueError("cover needs a fresh AI art prompt, two title lines, eyebrow, subline, and one frame")
    if cover.get("style") == "creator_collage":
        raise ValueError("creator_collage requires compose_collage with --portrait-source")
    src = Image.open(art).convert("RGB")
    scale = max(W/src.width, H/src.height)
    src = src.resize((round(src.width*scale), round(src.height*scale)), Image.Resampling.LANCZOS)
    x = (src.width-W)//2
    y = (src.height-H)//2
    img = src.crop((x, y, x+W, y+H)).convert("RGBA")
    shade = Image.new("RGBA", (W,H), (0,0,0,0))
    sd = ImageDraw.Draw(shade, "RGBA")
    for yy in range(170, 690, 4):
        strength = round(105 * (1-abs(yy-420)/350))
        sd.rectangle((0,yy,W,yy+4), fill=(9,25,37,max(0,strength)))
    img = Image.alpha_composite(img, shade)
    d = ImageDraw.Draw(img)
    paper = (247,245,238)
    coral = (238,133,95)
    center = W//2
    d.rounded_rectangle((center-185,195,center+185,249), radius=14, fill=coral)
    d.text((center,222), cover["eyebrow"], font=fit(d,cover["eyebrow"],32,335),
           fill=(14,35,47), anchor="mm")
    for line, yy, size in zip(lines,(340,455),(92,78)):
        d.text((center,yy),line,font=fit(d,line,size,760),fill=paper,anchor="mm",
               stroke_width=2,stroke_fill=(10,28,39))
    d.line((center-95,538,center+95,538),fill=coral,width=5)
    d.text((center,592),cover["subline"],font=fit(d,cover["subline"],42,760),
           fill=paper,anchor="mm",stroke_width=1,stroke_fill=(10,28,39))
    target.parent.mkdir(parents=True, exist_ok=True)
    img.convert("RGB").save(target, quality=95)


def compose_collage(art: Path, portrait_source: Path, plan: dict, target: Path):
    cover = plan.get("cover") or {}
    lines = cover.get("title_lines") or []
    if cover.get("duration_frames") != 1 or len(lines) != 2 or not cover.get("art_prompt"):
        raise ValueError("collage cover needs two title lines, one frame, and project-specific AI art")
    side = cover.get("portrait_side", "right")
    if side not in ("left", "right"):
        raise ValueError("cover.portrait_side must be left or right")
    cream=(247,241,226); black=(24,28,29); red=(187,56,42); orange=(230,121,58)
    canvas=Image.new("RGB",(W,H),cream)
    d=ImageDraw.Draw(canvas)
    # Paper grain and deliberate editorial grid; keep all key type inside 100..900.
    for x in range(70,W,32):
        d.line((x,100,x,H-220),fill=(242,232,215),width=1)
    d.rounded_rectangle((86,116,395,169),radius=8,fill=black)
    d.text((240,142),cover.get("eyebrow","口播 / NOTES"),font=fit(d,cover.get("eyebrow","口播 / NOTES"),30,280),fill=cream,anchor="mm")
    d.text((92,220),lines[0],font=fit(d,lines[0],113,800),fill=black,stroke_width=1,stroke_fill=black)
    d.rounded_rectangle((85,389,895,517),radius=7,fill=(255,250,239))
    d.text((104,453),lines[1],font=fit(d,lines[1],86,760),fill=red,anchor="lm",stroke_width=1,stroke_fill=red)
    d.line((110,540,680,540),fill=orange,width=13)
    art_img=Image.open(art).convert("RGB")
    # AI art supplies topic-specific paper props; the speaker comes only from this video's source.
    calendar=ImageOps.fit(art_img,(405,405),method=Image.Resampling.LANCZOS,centering=(.14,.52))
    resume=ImageOps.fit(art_img,(380,300),method=Image.Resampling.LANCZOS,centering=(.72,.78))
    def paper_card(piece, size, angle, point):
        card=Image.new("RGBA",(size[0]+30,size[1]+30),(255,252,243,255))
        card.paste(piece,(15,15))
        rotated=card.rotate(angle,expand=True,resample=Image.Resampling.BICUBIC)
        pos = (W-point[0]-rotated.width, point[1]) if side == "left" else point
        canvas.paste(rotated,pos,rotated)
    paper_card(calendar,(405,405),6,(70,640))
    paper_card(resume,(380,300),-5,(100,1100))
    person=Image.open(portrait_source).convert("RGB")
    person=ImageOps.fit(person,(450,835),method=Image.Resampling.LANCZOS,centering=(.5,.37))
    frame=Image.new("RGB",(474,859),(255,251,242));frame.paste(person,(12,12))
    portrait_x = 106 if side == "left" else 500
    canvas.paste(frame,(portrait_x,600))
    d=ImageDraw.Draw(canvas)
    divider_x = 594 if side == "left" else 470
    d.rectangle((divider_x,600,divider_x+16,1460),fill=black)
    prop_label = cover.get("prop_label")
    if prop_label and side == "right":
        d.rounded_rectangle((90,980,376,1060),radius=7,fill=black)
        d.text((232,1020),prop_label,font=fit(d,prop_label,42,255),fill=cream,anchor="mm")
    footer_paper = cover.get("footer_style") == "paper"
    d.rounded_rectangle((105,1458,895,1640),radius=12,fill=cream if footer_paper else (20,45,62),
                        outline=black if footer_paper else None,width=3)
    bottom=cover.get("subline")
    if not bottom:
        raise ValueError("cover.subline is required")
    d.text((500,1548),bottom,font=fit(d,bottom,83,735),fill=black if footer_paper else (255,226,143),anchor="mm")
    footer = cover.get("footer_label",cover.get("eyebrow",""))
    d.text((94,1725),footer,font=fit(d,footer,30,680),fill=(73,82,81))
    target.parent.mkdir(parents=True,exist_ok=True)
    canvas.save(target)


def prepend(cover: Path, video: Path, out: Path):
    frames = probe_frames(video)
    filtergraph = ("[0:v]trim=end_frame=1,setpts=PTS-STARTPTS[c];"
                   "[1:v]setpts=PTS-STARTPTS[v];"
                   "[c][v]concat=n=2:v=1:a=0,format=yuv420p[vo];"
                   "[1:a]adelay=33:all=1[a]")
    subprocess.run(["ffmpeg","-y","-hide_banner","-loglevel","error",
                    "-loop","1","-framerate",str(FPS),"-i",str(cover),"-i",str(video),
                    "-filter_complex",filtergraph,"-map","[vo]","-map","[a]",
                    "-frames:v",str(frames+1),"-r",str(FPS),"-c:v","libx264",
                    "-preset","veryfast","-crf","17","-c:a","aac","-b:a","192k",
                    str(out)],check=True)
    actual = probe_frames(out)
    if actual != frames+1:
        raise RuntimeError(f"cover frame check failed: {actual} != {frames}+1")
    return frames, actual


if __name__ == "__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--project",type=Path,required=True)
    ap.add_argument("--plan",type=Path,required=True)
    ap.add_argument("--art",type=Path,required=True)
    ap.add_argument("--portrait-source",type=Path)
    ap.add_argument("--video",type=Path,required=True)
    ap.add_argument("--cover",type=Path,required=True)
    ap.add_argument("--out",type=Path,required=True)
    a=ap.parse_args()
    plan=json.loads(a.plan.read_text(encoding="utf-8"))
    if plan.get("cover",{}).get("style") == "creator_collage":
        if not a.portrait_source:
            raise ValueError("creator_collage requires --portrait-source from this project's video")
        compose_collage(a.art,a.portrait_source,plan,a.cover)
    else:
        compose(a.art,plan,a.cover)
    before,after=prepend(a.cover,a.video,a.out)
    report={"ai_art":str(a.art.resolve()),"cover":str(a.cover.resolve()),
            "input":str(a.video.resolve()),"output":str(a.out.resolve()),
            "source_frames":before,"delivered_frames":after,"cover_frames":1,
            "music_profile":plan.get("music_profile")}
    (a.project/"intermediate").mkdir(parents=True,exist_ok=True)
    (a.project/"intermediate"/"cover_intro_trace.json").write_text(
        json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    print(f"[cover] {before} + 1 = {after} frames -> {a.out}")
