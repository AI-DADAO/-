#!/usr/bin/env python3
"""Check director-plan coverage, actual render trace, media, and beat contact sheet."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import subprocess
import wave
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageStat


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()


def probe(path):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                        "-of", "csv=p=0", str(path)], capture_output=True, text=True, check=True)
    return float(r.stdout.strip())


def music_level(path):
    with wave.open(str(path), "rb") as f:
        import numpy as np
        x = np.frombuffer(f.readframes(f.getnframes()), dtype="<i2").astype(np.float32)/32768
    return 20*math.log10(float(np.sqrt(np.mean(x*x)))+1e-12)


def run(project, plan_path=None, source=None, rendered=None, media=None):
    inter = project / "intermediate"
    out = project / "output"
    plan_path = plan_path or inter / "director_plan.json"
    source = source or out / "final.mp4"
    rendered = rendered or out / "final-director.mp4"
    media = media or out / "final-director-bgm.mp4"
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    trace = json.loads((inter / "director_render_trace.json").read_text(encoding="utf-8"))
    sound = json.loads((inter / "director_sound_trace.json").read_text(encoding="utf-8"))
    beats = plan["beats"]
    checks = []
    errors = []
    def check(name, yes, detail=""):
        (checks if yes else errors).append({"check":name, "detail":detail})
    fresh_duration = probe(source)
    check("micro-beat density", len(beats) >= max(3, math.ceil(fresh_duration/4)), f"{len(beats)} beats")
    check("continuous plan", all(abs(a["end"]-b["start"]) < .04 for a,b in zip(beats,beats[1:])))
    check("route diversity", len({b["route"] for b in beats}) == 3)
    identity = plan.get("visual_identity") or {}
    check("project visual identity", identity.get("family") in ("editorial", "ledger", "signal")
          and bool(identity.get("rationale")) and len(identity.get("distinctive_compositions", [])) >= 2,
          str(identity))
    check("rendered visual identity", trace.get("visual_identity") == identity)
    check("renderer consumed every beat", [b["id"] for b in beats] == [b["beat"] for b in trace["beats"]])
    check("rendered plan data", all(a["route"] == b["route"] and a["focus"] == b["focus"]
                                                and a["headline"] == b["headline"] and a["layout"] == b["layout"]
                                                and a.get("visual") == b.get("visual")
                                                and a.get("items") == b.get("items")
                                                and a.get("callout") == b.get("callout")
                                                for a,b in zip(beats,trace["beats"])))
    sound_expected = [(b["id"], b["sfx"]) for b in beats if b["sfx"] != "none"]
    sound_actual = [(e["beat"], e["kind"]) for e in sound["events"]]
    check("sound follows plan", sound_expected == sound_actual)
    check("music follows content profile", bool(plan.get("music_profile", {}).get("rationale"))
          and sound.get("music_profile") == plan.get("music_profile"),
          str(plan.get("music_profile")))
    check("fresh cut is render source", Path(trace["source"]).resolve() == source.resolve())
    check("plan is render source", Path(trace["plan"]).resolve() == plan_path.resolve())
    check("sound uses latest render", Path(sound["video"]).resolve() == rendered.resolve())
    check("duration", abs(probe(media) - fresh_duration) < .2,
          f"delivered={probe(media):.3f}s fresh-cut={fresh_duration:.3f}s")
    check("delivered after fresh cut", media.stat().st_mtime > source.stat().st_mtime)
    music_db=music_level(Path(sound["music_stem"]))
    check("audible restrained BGM", -35 <= music_db <= -22, f"music RMS={music_db:.1f} dBFS")
    if source.name == "final-tight.mp4":
        pause_report=json.loads((inter/"pause_report.json").read_text(encoding="utf-8"))
        check("reviewed pause cuts applied", len(pause_report["cuts"]) >= 1 and pause_report["total_removed"] > .05,
              f"{len(pause_report['cuts'])} cuts, {pause_report['total_removed']:.3f}s")
        from tighten_pauses import audio, candidates, map_time
        remaining=candidates(audio(source))
        cuts=[(c["start"],c["end"]) for c in pause_report["cuts"]]
        mapped=[map_time(a,cuts) for a,_ in cuts]
        bad=[x for x in remaining if any(abs((x["start"]+x["end"])/2-t)<.35 for t in mapped)]
        check("marked pauses now below 180ms", not bad, str(bad))
    safe=plan.get("safe_area")
    if plan.get("delivery_profile")=="douyin_preview":
        from director_render import SAFE_TOP, SAFE_RIGHT, SUBTITLE_Y, MAIN_CENTER, MAIN_LEFT, W
        check("Douyin safe-area profile", bool(safe) and safe.get("top")==SAFE_TOP
              and safe.get("right_edge")==SAFE_RIGHT and safe.get("subtitle_y")==SUBTITLE_Y)
        check("canvas center stays centered", MAIN_CENTER == W//2 and MAIN_LEFT + SAFE_RIGHT == W
              and trace.get("canvas_center_x") == W//2,
              f"center={trace.get('canvas_center_x')}, content={MAIN_LEFT}..{SAFE_RIGHT}")
    frame_dir = inter / "director_qc_frames"
    frame_dir.mkdir(exist_ok=True)
    thumbs = []
    font = ImageFont.truetype(r"C:\Windows\Fonts\msyhbd.ttc", 23)
    for b in beats:
        mid = (b["start"]+b["end"])/2
        frame = frame_dir / f"{b['id']}.jpg"
        subprocess.run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-ss", str(mid),
                        "-i", str(media), "-frames:v", "1", str(frame)], check=True)
        img = Image.open(frame).convert("RGB")
        if b["layout"] == "abc_summary":
            # Locate the large accent-colored 80% mark, excluding the small header tag.
            sx, sy = img.width/720, img.height/1280
            accent = tuple(bytes.fromhex(plan.get("palette", {}).get("accent", "#E67B5E").lstrip("#")))
            pixels = img.load()
            xs = []
            for yy in range(round(510*sy), round(690*sy), 3):
                for xx in range(round(120*sx), round(600*sx), 3):
                    c = pixels[xx, yy]
                    if sum(abs(c[j]-accent[j]) for j in range(3)) < 85:
                        xs.append(xx/sx)
            center = sum(xs)/len(xs) if xs else -1
            check("hero mark centered", len(xs)>30 and abs(center-360)<25,
                  f"accent centroid x={center:.1f}, samples={len(xs)}")
        stat = ImageStat.Stat(img)
        check(f"nonblank {b['id']}", max(stat.stddev) > 18, f"std={max(stat.stddev):.1f}")
        img.thumbnail((180, 320))
        tile = Image.new("RGB", (180, 350), (16, 36, 51))
        tile.paste(img, ((180-img.width)//2, 0))
        ImageDraw.Draw(tile).text((10, 323), f"{b['id']} {b['route']}", font=font, fill=(241,238,229))
        thumbs.append(tile)
    sheet = Image.new("RGB", (1080, 1050), (16, 36, 51))
    for i, tile in enumerate(thumbs):
        sheet.paste(tile, ((i%6)*180, (i//6)*350))
    found = re.search(r"v\d+", media.stem)
    version = found.group(0) if found else ""
    sheet_path=project / (f"director-contact-sheet-{version}.jpg" if version else "director-contact-sheet.jpg")
    sheet.save(sheet_path, quality=88)
    if safe:
        proof=Image.open(frame_dir / f"{beats[-4]['id']}.jpg").convert("RGBA")
        overlay=Image.new("RGBA",proof.size,(0,0,0,0))
        d=ImageDraw.Draw(overlay,"RGBA")
        sx=proof.width/720; sy=proof.height/1280
        d.rectangle((0,0,proof.width,int(safe["top"]*sy)),fill=(225,60,60,90))
        d.rectangle((int(safe["right_edge"]*sx),0,proof.width,proof.height),fill=(225,60,60,85))
        d.rectangle((0,int((1280-safe["bottom"])*sy),proof.width,proof.height),fill=(225,60,60,100))
        Image.alpha_composite(proof,overlay).convert("RGB").save(project/(f"douyin-safe-preview-{version}.jpg" if version else "douyin-safe-preview.jpg"),quality=90)
    # Hashes distinguish the only imported content inputs from generated products.
    provenance = {"project":str(project), "inputs":{
        "video.mp4":sha(project / "video.mp4"),
        "target_script.md":sha(project / "target_script.md")},
        "generated":{p.name:sha(p) for p in [source, rendered, media]},
        "render_source":trace["source"]}
    (inter / "provenance.json").write_text(json.dumps(provenance, ensure_ascii=False, indent=2), encoding="utf-8")
    report = {"passed":checks, "failed":errors, "beat_count":len(beats),
              "contact_sheet":str(sheet_path)}
    (inter / "director_qc_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[director-qc] {len(checks)} pass / {len(errors)} fail; {len(beats)} beat frames")
    for e in errors:
        print("[FAIL]", e)
    return 1 if errors else 0


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", type=Path, required=True)
    ap.add_argument("--plan", type=Path)
    ap.add_argument("--source", type=Path)
    ap.add_argument("--rendered", type=Path)
    ap.add_argument("--deliverable", type=Path)
    a = ap.parse_args()
    raise SystemExit(run(a.project.resolve(), a.plan, a.source, a.rendered, a.deliverable))
