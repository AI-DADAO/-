#!/usr/bin/env python3
"""Run the bundled raw-take editor without depending on another installed Skill."""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

ENGINE = Path(__file__).resolve().parent.parent / "assets" / "oral-engine" / "scripts"


def call(script: str, *args: str) -> None:
    subprocess.run([sys.executable, str(ENGINE / script), *map(str, args)], check=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("stage", choices=("prepare", "finalize"))
    ap.add_argument("--project", required=True, type=Path)
    ap.add_argument("--video", required=True, type=Path)
    ap.add_argument("--target", required=True, type=Path)
    ap.add_argument("--model", default="base")
    a = ap.parse_args()
    project, video, target = a.project.resolve(), a.video.resolve(), a.target.resolve()
    if not video.is_file() or not target.is_file():
        raise FileNotFoundError("raw-take video and target script must exist")
    inter, out = project / "intermediate", project / "output"
    inter.mkdir(parents=True, exist_ok=True)
    out.mkdir(parents=True, exist_ok=True)
    if a.stage == "prepare":
        call("run_all.py", "--video", str(video), "--target", str(target),
             "--workdir", str(project), "--model", a.model, "--device", "cpu",
             "--compute-type", "int8")
        print(f"Review {inter / '06_report.html'} and export {inter / '07_reviewed_edl.json'}")
    else:
        reviewed = inter / "07_reviewed_edl.json"
        if not reviewed.is_file():
            raise FileNotFoundError(f"reviewed EDL missing: {reviewed}")
        call("stage6_finalize.py", "--video", str(video), "--reviewed-edl", str(reviewed),
             "--aligned", str(inter / "03_aligned.json"), "--out-video", str(out / "final.mp4"),
             "--out-srt", str(out / "final.srt"), "--breath-gap", "0.08")
        call("stage6b_srt_seg.py", "--final-video", str(out / "final.mp4"),
             "--target", str(target), "--out", str(out / "final.srt"), "--model", a.model)
        print(f"Ready: {out / 'final.mp4'} and {out / 'final.srt'}")


if __name__ == "__main__":
    main()
