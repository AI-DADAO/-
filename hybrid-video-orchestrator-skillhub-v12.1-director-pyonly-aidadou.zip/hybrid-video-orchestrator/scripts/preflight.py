#!/usr/bin/env python3
"""Check whether this machine can run the prepared-cut or raw-take workflow."""
from __future__ import annotations

import argparse
import importlib.util
import json
import os
import shutil
import sys
from pathlib import Path

from font_paths import cjk_font


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=("prepared", "raw"), default="prepared")
    ap.add_argument("--skip-model-check", action="store_true", help="diagnostic install only")
    args = ap.parse_args()
    checks = {"python_3_10_plus": sys.version_info >= (3, 10)}
    for package in ("PIL", "numpy"):
        checks[package] = importlib.util.find_spec(package) is not None
    for command in ("ffmpeg", "ffprobe"):
        checks[command] = shutil.which(command) is not None
    try:
        cjk_font(); cjk_font(bold=True)
        checks["cjk_fonts"] = True
    except FileNotFoundError:
        checks["cjk_fonts"] = False
    if args.mode == "raw":
        engine = Path(__file__).resolve().parent.parent / "assets" / "oral-engine"
        checks["bundled_oral_engine"] = (engine / "scripts" / "run_all.py").is_file() and (engine / "templates" / "report_template.txt").is_file()
        checks["faster_whisper"] = importlib.util.find_spec("faster_whisper") is not None
        checks["rapidfuzz"] = importlib.util.find_spec("rapidfuzz") is not None
        if not args.skip_model_check:
            hf = Path(os.environ.get("HF_HOME", Path.home() / ".cache" / "huggingface"))
            checks["asr_base_model"] = any(hf.glob("hub/models--Systran--faster-whisper-base/snapshots/*/model.bin"))
    print(json.dumps({"mode": args.mode, "checks": checks,
                      "ready": all(checks.values()),
                      "note": "AI image generation and online library access require agent/tool and network checks per project"},
                     ensure_ascii=False, indent=2))
    return 0 if all(checks.values()) else 1


if __name__ == "__main__":
    raise SystemExit(main())
