#!/usr/bin/env python3
"""Install the Windows-first runtime in the buyer's user profile, then verify it."""
from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import subprocess
import sys
import venv
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
LOCAL = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
RUNTIME = LOCAL / "HVO" / "v11"


def locate(name: str) -> Path | None:
    found = shutil.which(name)
    if found:
        return Path(found).resolve()
    if name.startswith("ff"):
        roots = [LOCAL / "Microsoft" / "WinGet" / "Packages",
                 Path(os.environ.get("PROGRAMFILES", r"C:\Program Files")) / "WinGet" / "Packages"]
        for root in roots:
            if root.is_dir():
                for package in root.glob("Gyan.FFmpeg_*"):
                    match = next(package.glob(f"**/{name}.exe"), None)
                    if match:
                        return match.resolve()
    if name == "node":
        match = Path(os.environ.get("PROGRAMFILES", r"C:\Program Files")) / "nodejs" / "node.exe"
        if match.is_file():
            return match
    return None


def install_winget(package: str) -> None:
    winget = shutil.which("winget")
    if not winget:
        raise RuntimeError(f"{package} is missing and WinGet is unavailable; install it from its official site")
    subprocess.run([winget, "install", "--id", package, "--exact", "--source", "winget",
                    "--silent", "--accept-package-agreements", "--accept-source-agreements"], check=True)
    os.environ["PATH"] = os.pathsep.join(filter(None, [
        os.environ.get("PATH", ""),
        str(LOCAL / "Microsoft" / "WinGet" / "Links"),
        str(Path(os.environ.get("PROGRAMFILES", r"C:\Program Files")) / "nodejs"),
    ]))


def ensure(name: str, package: str) -> Path:
    result = locate(name)
    if result:
        return result
    install_winget(package)
    result = locate(name)
    if not result:
        raise RuntimeError(f"{package} installed but {name} is not discoverable; reopen terminal and retry")
    return result


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--check-only", action="store_true")
    ap.add_argument("--skip-model-download", action="store_true")
    ap.add_argument("--prepared-only", action="store_true")
    a = ap.parse_args()
    if sys.version_info[:2] != (3, 13):
        raise RuntimeError("This Windows release is tested with Python 3.13 only")
    if os.name != "nt":
        raise RuntimeError("The one-click installer currently supports Windows only")
    if platform.machine().lower() not in ("amd64", "x86_64"):
        raise RuntimeError("The one-click installer currently supports Windows x64 only")
    status = {"python": sys.executable, "ffmpeg": str(locate("ffmpeg") or ""),
              "ffprobe": str(locate("ffprobe") or ""),
              "node": str(locate("node") or ""),
              "runtime_exists": (RUNTIME / ".venv" / "Scripts" / "python.exe").is_file()}
    if a.check_only:
        config_path = RUNTIME / "runtime.json"
        status["runtime_config"] = config_path.is_file()
        status["preflight_ready"] = False
        if config_path.is_file():
            try:
                config = json.loads(config_path.read_text(encoding="utf-8"))
                installed_python = Path(config["python"])
                if installed_python.is_file():
                    env = os.environ.copy()
                    env["PATH"] = str(config["ffmpeg_bin"]) + os.pathsep + env.get("PATH", "")
                    env["HF_HOME"] = str(config["hf_home"])
                    mode = config.get("mode", "raw")
                    check = subprocess.run(
                        [str(installed_python), str(ROOT / "scripts" / "preflight.py"), "--mode", mode],
                        env=env, capture_output=True, text=True, timeout=60,
                    )
                    status["preflight_ready"] = check.returncode == 0
                    if check.stdout:
                        status["preflight"] = json.loads(check.stdout)
            except (OSError, KeyError, ValueError, subprocess.SubprocessError) as exc:
                status["preflight_error"] = type(exc).__name__
        print(json.dumps(status, indent=2))
        return 0 if status["runtime_exists"] and status["runtime_config"] and status["preflight_ready"] else 1

    ffmpeg = ensure("ffmpeg", "Gyan.FFmpeg")
    ffprobe = ensure("ffprobe", "Gyan.FFmpeg")
    node = locate("node")
    RUNTIME.mkdir(parents=True, exist_ok=True)
    venv_dir = RUNTIME / ".venv"
    if not (venv_dir / "Scripts" / "python.exe").is_file():
        venv.EnvBuilder(with_pip=True).create(venv_dir)
    python = venv_dir / "Scripts" / "python.exe"
    requirements = ROOT / ("requirements-director.txt" if a.prepared_only else "requirements-lock-win-py313.txt")
    subprocess.run([str(python), "-m", "pip", "install", "--disable-pip-version-check", "--no-input",
                    "-r", str(requirements)], check=True)
    hf_home = RUNTIME / "huggingface"
    env = os.environ.copy()
    env["PATH"] = str(ffmpeg.parent) + os.pathsep + env.get("PATH", "")
    env["HF_HOME"] = str(hf_home)
    if not a.prepared_only and not a.skip_model_download:
        try:
            subprocess.run([str(python), "-c",
                            "from faster_whisper import WhisperModel; WhisperModel('base',device='cpu',compute_type='int8'); print('ASR base model ready')"],
                           env=env, check=True)
        except subprocess.CalledProcessError:
            raise SystemExit("ASR base model could not be downloaded from Hugging Face. Check network access, then rerun scripts/bootstrap.py; prepared-cut mode remains available with --prepared-only.") from None
    mode = "prepared" if a.prepared_only else "raw"
    preflight_args = [str(python), str(ROOT / "scripts" / "preflight.py"), "--mode", mode]
    if a.skip_model_download and not a.prepared_only:
        preflight_args.append("--skip-model-check")
    subprocess.run(preflight_args,
                   env=env, check=True)
    config = {"version": 11, "python": str(python), "ffmpeg_bin": str(ffmpeg.parent),
              "ffprobe": str(ffprobe), "node": str(node or ""), "hf_home": str(hf_home),
              "mode": mode, "asr_model_ready": bool(not a.prepared_only and not a.skip_model_download)}
    (RUNTIME / "runtime.json").write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
    if a.skip_model_download and not a.prepared_only:
        print("Core runtime installed for diagnostics; ASR model missing. Rerun scripts/bootstrap.py without --skip-model-download for raw editing.")
    else:
        print(f"Install complete: {RUNTIME / 'runtime.json'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
