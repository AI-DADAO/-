# 著作权与许可

© 2026 AI大道。

AI大道对本包中由其创作的 Skill 指令、导演流程、设计规则、编排与渲染代码及文档主张著作权。除已明确授予的许可或另行授权外，保留相关权利。

本声明不改变 `assets/oral-engine` 按 Apache License 2.0 分发的许可；其许可全文和原有署名分别见 `assets/oral-engine/LICENSE.txt` 与 `assets/oral-engine/NOTICE.txt`。第三方依赖、字体、音乐、图片及用户提供的素材按各自许可和权利归属处理。
